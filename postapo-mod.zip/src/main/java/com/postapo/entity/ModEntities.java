package com.postapo.entity;

import com.postapo.PostApoMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, PostApoMod.MODID);

    /** Мутант: обычный враг в руинах и на улицах. */
    public static final Supplier<EntityType<MutantEntity>> MUTANT = ENTITIES.register("mutant",
            () -> EntityType.Builder.of(MutantEntity::new, MobCategory.MONSTER)
                    .sized(0.7f, 2.0f)
                    .build("mutant"));

    /** Сталкер: быстрее мутанта, но слабее. Бродит по заброшенным улицам. */
    public static final Supplier<EntityType<StalkerEntity>> STALKER = ENTITIES.register("stalker",
            () -> EntityType.Builder.of(StalkerEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.9f)
                    .build("stalker"));

    /** Пепельный король: финальный босс главы 9. Вызывается командой или из сигнального устройства. */
    public static final Supplier<EntityType<AshKingEntity>> ASH_KING = ENTITIES.register("ash_king",
            () -> EntityType.Builder.of(AshKingEntity::new, MobCategory.MONSTER)
                    .sized(1.2f, 3.2f)
                    .fireImmune()
                    .build("ash_king"));
}
