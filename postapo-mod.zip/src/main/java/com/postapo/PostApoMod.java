package com.postapo;

import com.mojang.logging.LogUtils;
import com.postapo.compat.TaczCompat;
import com.postapo.entity.ModEntities;
import com.postapo.story.StoryManager;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

@Mod(PostApoMod.MODID)
public class PostApoMod {
    public static final String MODID = "postapo";
    public static final Logger LOGGER = LogUtils.getLogger();

    public PostApoMod(IEventBus modEventBus) {
        ModItems.ITEMS.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);
        StoryManager.ATTACHMENTS.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);

        TaczCompat.init();
        LOGGER.info("Пепел: мод загружен");
    }
}
