package com.postapo.story;

import com.mojang.serialization.Codec;
import com.postapo.PostApoMod;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.function.Supplier;

/**
 * Сюжет: игрок проходит главы, находя фрагменты радиоприёмника.
 * Прогресс хранится как attachment, копируется при смерти игрока.
 */
public final class StoryManager {
    public static final int CHAPTERS = 10;

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, PostApoMod.MODID);

    public static final Supplier<AttachmentType<Integer>> CHAPTER = ATTACHMENTS.register("chapter",
            () -> AttachmentType.builder(() -> 0)
                    .serialize(Codec.INT)
                    .copyOnDeath()
                    .build());

    private StoryManager() {
    }

    public static int getChapter(ServerPlayer player) {
        return player.getData(CHAPTER.get());
    }

    /** Переход к следующей главе. Возвращает false, если история уже завершена. */
    public static boolean advance(ServerPlayer player) {
        int next = getChapter(player) + 1;
        if (next > CHAPTERS) {
            return false;
        }
        player.setData(CHAPTER.get(), next);
        player.sendSystemMessage(Component.translatable("postapo.story.chapter." + next + ".title")
                .withStyle(ChatFormatting.GOLD));
        player.sendSystemMessage(Component.translatable("postapo.story.chapter." + next + ".text")
                .withStyle(ChatFormatting.GRAY));
        return true;
    }
}
