package com.postapo.story;

import com.postapo.ModItems;
import com.postapo.PostApoMod;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.ItemEntityPickupEvent;

@EventBusSubscriber(modid = PostApoMod.MODID)
public final class StoryEvents {
    private StoryEvents() {
    }

    @SubscribeEvent
    public static void onPickup(ItemEntityPickupEvent.Post event) {
        if (!(event.getPlayer() instanceof ServerPlayer player)) {
            return;
        }
        if (event.getItemEntity().getItem().is(ModItems.RADIO_FRAGMENT.get())) {
            StoryManager.advance(player);
        }
    }
}
