package com.postapo.client;

import com.postapo.PostApoMod;
import com.postapo.entity.AshKingEntity;
import com.postapo.entity.ModEntities;
import com.postapo.entity.MutantEntity;
import com.postapo.entity.StalkerEntity;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = PostApoMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private static final ResourceLocation TEX_MUTANT =
            ResourceLocation.fromNamespaceAndPath(PostApoMod.MODID, "textures/entity/mutant.png");
    private static final ResourceLocation TEX_STALKER =
            ResourceLocation.fromNamespaceAndPath(PostApoMod.MODID, "textures/entity/stalker.png");
    private static final ResourceLocation TEX_ASH_KING =
            ResourceLocation.fromNamespaceAndPath(PostApoMod.MODID, "textures/entity/ash_king.png");

    private ClientModEvents() {
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(MutantModel.LAYER, MutantModel::createLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.MUTANT.get(),
                ctx -> new ZombieLikeRenderer<MutantEntity>(ctx, TEX_MUTANT, 1.0F, 0.5F));
        event.registerEntityRenderer(ModEntities.STALKER.get(),
                ctx -> new ZombieLikeRenderer<StalkerEntity>(ctx, TEX_STALKER, 0.95F, 0.45F));
        event.registerEntityRenderer(ModEntities.ASH_KING.get(),
                ctx -> new ZombieLikeRenderer<AshKingEntity>(ctx, TEX_ASH_KING, 1.8F, 1.2F));
    }
}
