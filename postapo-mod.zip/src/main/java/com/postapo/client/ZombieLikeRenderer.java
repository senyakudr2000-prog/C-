package com.postapo.client;

import com.postapo.entity.MutantEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Общий рендерер для мутанта, сталкера и босса. Размер и текстура задаются при создании. */
public class ZombieLikeRenderer<T extends MutantEntity> extends MobRenderer<T, MutantModel<T>> {
    private final ResourceLocation texture;

    public ZombieLikeRenderer(EntityRendererProvider.Context context, ResourceLocation texture,
                              float scale, float shadowRadius) {
        super(context, new MutantModel<T>(context.bakeLayer(MutantModel.LAYER), scale), shadowRadius);
        this.texture = texture;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

}
