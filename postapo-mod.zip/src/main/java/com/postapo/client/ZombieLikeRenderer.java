package com.postapo.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.postapo.entity.MutantEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Общий рендерер для мутанта, сталкера и босса. Размер и текстура задаются при создании. */
public class ZombieLikeRenderer<T extends MutantEntity> extends MobRenderer<T, MutantModel<T>> {
    private final ResourceLocation texture;
    private final float scale;

    public ZombieLikeRenderer(EntityRendererProvider.Context context, ResourceLocation texture,
                              float scale, float shadowRadius) {
        super(context, new MutantModel<T>(context.bakeLayer(MutantModel.LAYER)), shadowRadius);
        this.texture = texture;
        this.scale = scale;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

    @Override
    protected void scale(T entity, PoseStack poseStack) {
        poseStack.scale(scale, scale, scale);
    }
}
