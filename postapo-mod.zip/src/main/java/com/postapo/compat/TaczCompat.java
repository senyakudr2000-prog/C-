package com.postapo.compat;

import com.postapo.PostApoMod;
import net.neoforged.fml.ModList;

/**
 * Опциональная совместимость с TaCZ.
 * Мод не имеет жёсткой зависимости: классы TaCZ не импортируются,
 * поэтому без TaCZ всё работает как обычно.
 * Патроны мода попадают в тег postapo:tacz_ammo, который можно подключить к оружию TaCZ.
 */
public final class TaczCompat {
    public static final String TACZ_MODID = "tacz";

    private TaczCompat() {
    }

    public static boolean isTaczLoaded() {
        return ModList.get().isLoaded(TACZ_MODID);
    }

    public static void init() {
        if (isTaczLoaded()) {
            PostApoMod.LOGGER.info("TaCZ найден: включена совместимость патронов постапокалипсиса");
        }
    }
}
