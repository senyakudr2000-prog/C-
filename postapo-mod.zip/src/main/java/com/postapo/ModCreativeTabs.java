package com.postapo;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PostApoMod.MODID);

    public static final Supplier<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.postapo"))
            .icon(() -> ModItems.RADIO_FRAGMENT.get().getDefaultInstance())
            .displayItems((params, output) -> {
                output.accept(ModItems.RADIO_FRAGMENT.get());
                output.accept(ModItems.SCRAP_METAL.get());
                output.accept(ModItems.RUSTY_PIPE.get());
                output.accept(ModItems.KNIFE.get());
                output.accept(ModItems.CANNED_FOOD.get());
                output.accept(ModItems.WATER_BOTTLE.get());
                output.accept(ModItems.BANDAGE.get());
                output.accept(ModItems.MEDKIT.get());
                output.accept(ModItems.AMMO_9MM.get());
            })
            .build());
}
