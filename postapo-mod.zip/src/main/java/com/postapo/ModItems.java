package com.postapo;

import com.postapo.item.HealingItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(PostApoMod.MODID);

    /** Сюжетные фрагменты. Каждый найденный фрагмент продвигает главу истории. */
    public static final DeferredItem<Item> RADIO_FRAGMENT =
            ITEMS.registerSimpleItem("radio_fragment", new Item.Properties().stacksTo(16));

    public static final DeferredItem<Item> SCRAP_METAL =
            ITEMS.registerSimpleItem("scrap_metal", new Item.Properties().stacksTo(64));

    public static final DeferredItem<Item> RUSTY_PIPE =
            ITEMS.registerSimpleItem("rusty_pipe", new Item.Properties().durability(120));

    public static final DeferredItem<Item> KNIFE =
            ITEMS.registerSimpleItem("knife", new Item.Properties().durability(200));

    public static final DeferredItem<Item> CANNED_FOOD =
            ITEMS.registerSimpleItem("canned_food", new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.6f).build()));

    public static final DeferredItem<Item> WATER_BOTTLE =
            ITEMS.registerSimpleItem("water_bottle", new Item.Properties().stacksTo(8)
                    .food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.3f).build()));

    /** Патрон. Помечен тегом postapo:tacz_ammo для совместимости с TaCZ. */
    public static final DeferredItem<Item> AMMO_9MM =
            ITEMS.registerSimpleItem("ammo_9mm", new Item.Properties().stacksTo(64));

    public static final DeferredItem<HealingItem> BANDAGE =
            ITEMS.register("bandage", () -> new HealingItem(new Item.Properties().stacksTo(16), 4.0F));

    public static final DeferredItem<HealingItem> MEDKIT =
            ITEMS.register("medkit", () -> new HealingItem(new Item.Properties().stacksTo(4), 12.0F));
}
