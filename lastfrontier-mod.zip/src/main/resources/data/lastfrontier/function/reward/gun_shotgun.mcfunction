# ВАЖНО: синтаксис выдачи предметов TaCZ на 1.21.1 не проверен. Возьми оружие в руку и выполни /data get entity @s SelectedItem, затем подстрой строки ниже. Если строка некорректна, функция просто не загрузится, игра не упадёт.
give @s tacz:modern_kinetic_gun[minecraft:custom_data={GunId:"tacz:db_short"}]
