package com.lastfrontier;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = LastFrontier.MODID)
public final class StoryCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("lf")
                // /lf quest - текущая цель
                .then(Commands.literal("quest").executes(ctx -> {
                    StoryManager.showQuest(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                // /lf difficulty <easy|normal|hard|nightmare> - сила врагов
                .then(Commands.literal("difficulty")
                        .then(Commands.argument("level", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(
                                        java.util.List.of("easy", "normal", "hard", "nightmare"), b))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    String lv = StringArgumentType.getString(ctx, "level");
                                    if (!StoryManager.setDifficulty(p, lv)) {
                                        reply(ctx.getSource(), "§ceasy, normal, hard или nightmare");
                                        return 0;
                                    }
                                    reply(ctx.getSource(), "§6Сложность врагов: " + lv + " (новые враги будут такими).");
                                    return 1;
                                })))
                // /lf camp - вернуться в лагерь
                .then(Commands.literal("camp").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    City c = City.of(p);
                    if (c == null || !StoryManager.isReady(p)) {
                        reply(ctx.getSource(), "§cГород ещё не построен.");
                        return 0;
                    }
                    BlockPos s = c.playerSpawn();
                    p.teleportTo(s.getX() + 0.5, s.getY(), s.getZ() + 0.5);
                    return 1;
                }))
                // /lf tp <zone> - телепорт в зону (оп)
                .then(Commands.literal("tp").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("zone", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(City.ZONES.keySet(), b))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    City c = City.of(p);
                                    String z = StringArgumentType.getString(ctx, "zone");
                                    if (c == null || !City.ZONES.containsKey(z)) {
                                        reply(ctx.getSource(), "§cНет такой зоны.");
                                        return 0;
                                    }
                                    BlockPos s = c.safePos(z);
                                    p.teleportTo(s.getX() + 0.5, s.getY(), s.getZ() + 0.5);
                                    return 1;
                                })))
                // /lf npc <id> - поставить NPC перед собой (оп)
                .then(Commands.literal("npc").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(Npcs.NAMES.keySet(), b))
                                .executes(ctx -> {
                                    String id = StringArgumentType.getString(ctx, "id");
                                    if (!Npcs.NAMES.containsKey(id)) {
                                        reply(ctx.getSource(), "§cНет такого NPC.");
                                        return 0;
                                    }
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    Npcs.spawn(p.serverLevel(), id, p.blockPosition().relative(p.getDirection(), 3));
                                    return 1;
                                })))
                // /lf skip - пропустить квест (оп)
                .then(Commands.literal("skip").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    if (StoryManager.current(p) == null) return 0;
                    StoryManager.complete(p);
                    return 1;
                }))
                // /lf goto <n> - перейти к квесту n (оп)
                .then(Commands.literal("goto").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("n", IntegerArgumentType.integer(1))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    int n = IntegerArgumentType.getInteger(ctx, "n");
                                    StoryManager.data(p).putInt("idx", n - 1);
                                    StoryManager.startQuest(p);
                                    return 1;
                                })))
                // /lf reset - начать историю заново с новым городом (оп)
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    StoryManager.reset(p);
                    StoryManager.begin(p);
                    return 1;
                })));
    }

    private static void reply(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
    }

    private StoryCommands() {}
}
