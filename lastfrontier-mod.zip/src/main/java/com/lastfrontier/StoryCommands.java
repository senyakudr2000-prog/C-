package com.lastfrontier;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@EventBusSubscriber(modid = LastFrontier.MODID)
public final class StoryCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("lf")
                // /lf quest - текущая цель
                .then(Commands.literal("quest").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    Quest q = StoryManager.current(p);
                    if (q == null) {
                        reply(ctx.getSource(), "§6История завершена.");
                    } else {
                        reply(ctx.getSource(), "§6" + q.chapter());
                        reply(ctx.getSource(), "§e" + q.title() + " §7(" + (StoryManager.index(p) + 1)
                                + "/" + Quests.ALL.size() + ")");
                        reply(ctx.getSource(), "§7" + q.description());
                        reply(ctx.getSource(), "§fПрогресс: " + StoryManager.progress(p) + "/" + q.objective().count());
                    }
                    return 1;
                }))
                // /lf npc <id> - поставить NPC перед собой (оп)
                .then(Commands.literal("npc").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(Npcs.NAMES.keySet(), b))
                                .executes(ctx -> {
                                    String id = StringArgumentType.getString(ctx, "id");
                                    if (!Npcs.NAMES.containsKey(id)) {
                                        reply(ctx.getSource(), "§cНет такого NPC.");
                                        return 0;
                                    }
                                    StoryManager.run(ctx.getSource().getPlayerOrException(), Quests.npcSummon(id));
                                    return 1;
                                })))
                // /lf skip - пропустить квест (оп)
                .then(Commands.literal("skip").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    if (StoryManager.current(p) == null) return 0;
                    StoryManager.complete(p);
                    return 1;
                }))
                // /lf goto <n> - перейти к квесту n (оп)
                .then(Commands.literal("goto").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("n", IntegerArgumentType.integer(1))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    int n = IntegerArgumentType.getInteger(ctx, "n");
                                    StoryManager.data(p).putInt("idx", n - 1);
                                    StoryManager.startQuest(p);
                                    return 1;
                                })))
                // /lf reset - начать историю заново (оп)
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2)).executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    StoryManager.reset(p);
                    StoryManager.begin(p);
                    return 1;
                })));
    }

    private static void reply(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
    }

    private StoryCommands() {}
}
