package com.lastfrontier;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

@Mod(LastFrontier.MODID)
public class LastFrontier {
    public static final String MODID = "lastfrontier";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, MODID);

    // предметы истории
    public static final DeferredItem<Item> JOURNAL = ITEMS.register("survivor_journal",
            () -> new JournalItem(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> MEDKIT = ITEMS.register("medkit",
            () -> new MedkitItem(new Item.Properties().stacksTo(8)));
    public static final DeferredItem<Item> FUSE = ITEMS.registerSimpleItem("fuse", new Item.Properties().stacksTo(16));
    public static final DeferredItem<Item> BATTERY = ITEMS.registerSimpleItem("battery", new Item.Properties().stacksTo(16));
    public static final DeferredItem<Item> ANTENNA_CRYSTAL = ITEMS.registerSimpleItem("antenna_crystal", new Item.Properties().stacksTo(16));
    public static final DeferredItem<Item> KEYCARD = ITEMS.registerSimpleItem("keycard", new Item.Properties().stacksTo(16));

    public static final DeferredItem<Item> FUEL_CANISTER = ITEMS.registerSimpleItem("fuel_canister", new Item.Properties().stacksTo(16));
    public static final DeferredItem<Item> SCHEMATIC = ITEMS.registerSimpleItem("schematic", new Item.Properties().stacksTo(16));
    public static final DeferredItem<Item> MUTANT_SAMPLE = ITEMS.registerSimpleItem("mutant_sample", new Item.Properties().stacksTo(16));

    /** Записки-лор note_1 ... note_N. */
    public static final List<DeferredItem<Item>> NOTES = new ArrayList<>();

    static {
        for (int i = 0; i < Notes.TEXT.length; i++) {
            final int n = i;
            NOTES.add(ITEMS.register("note_" + (i + 1), () -> new NoteItem(new Item.Properties().stacksTo(1), n)));
        }
    }

    // реквизит в руках врагов (оружие не стреляет, это только внешний вид)
    public static final DeferredItem<Item> PROP_PISTOL = ITEMS.registerSimpleItem("prop_pistol", new Item.Properties().stacksTo(1));
    public static final DeferredItem<Item> PROP_RIFLE = ITEMS.registerSimpleItem("prop_rifle", new Item.Properties().stacksTo(1));
    public static final DeferredItem<Item> PROP_SHOTGUN = ITEMS.registerSimpleItem("prop_shotgun", new Item.Properties().stacksTo(1));
    public static final DeferredItem<Item> PROP_SNIPER = ITEMS.registerSimpleItem("prop_sniper", new Item.Properties().stacksTo(1));

    public static final DeferredHolder<EntityType<?>, EntityType<SurvivorEntity>> SURVIVOR = ENTITIES.register("survivor",
            () -> EntityType.Builder.of(SurvivorEntity::new, MobCategory.MISC)
                    .sized(0.6f, 1.95f)
                    .build("survivor"));

    public static final DeferredHolder<EntityType<?>, EntityType<RaiderEntity>> RAIDER = ENTITIES.register("raider",
            () -> EntityType.Builder.of(RaiderEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.95f)
                    .clientTrackingRange(8)
                    .build("raider"));

    public LastFrontier(IEventBus modBus) {
        ITEMS.register(modBus);
        ENTITIES.register(modBus);
        modBus.addListener(LastFrontier::onAttributes);
        modBus.addListener(LastFrontier::onCreativeTab);
        LOGGER.info("Last Frontier loaded. TaCZ present: {}", ModList.get().isLoaded("tacz"));
    }

    private static void onAttributes(EntityAttributeCreationEvent e) {
        e.put(SURVIVOR.get(), SurvivorEntity.createAttributes().build());
        e.put(RAIDER.get(), RaiderEntity.createAttributes().build());
    }

    private static void onCreativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            e.accept(JOURNAL.get());
            e.accept(MEDKIT.get());
            e.accept(FUSE.get());
            e.accept(BATTERY.get());
            e.accept(ANTENNA_CRYSTAL.get());
            e.accept(KEYCARD.get());
            e.accept(FUEL_CANISTER.get());
            e.accept(SCHEMATIC.get());
            e.accept(MUTANT_SAMPLE.get());
            for (DeferredItem<Item> note : NOTES) e.accept(note.get());
        }
    }
}
