package com.lastfrontier;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Consumer;

/**
 * Заброшенный город «Новый Приют»: сетка 5x5 кварталов (лот 12x12, дороги по 4 блока), 84x84 блока.
 * Раскладка зон фиксирована, поэтому позиции NPC, врагов и сундуков можно вычислить по одной точке (origin).
 * Юг (z+) - Южный пост (лагерь), север (z-) - радиовышка и бункер.
 */
public final class City {
    public static final int PITCH = 16;
    public static final int ROAD = 4;
    public static final int LOT = 12;
    public static final int N = 5;
    public static final int SIZE = N * PITCH + ROAD;
    public static final int CLEAR_H = 24;

    /** cells - клетки внутри лота (x,z), где появляются враги; npc - клетка NPC. */
    public record Zone(String id, String label, int li, int lj, int[][] cells, int[] npc) {}

    public record Put(BlockPos pos, BlockState state) {}

    public static final Map<String, Zone> ZONES = new LinkedHashMap<>();
    /** Какой NPC стоит в какой зоне. */
    public static final Map<String, String> NPC_AT = new LinkedHashMap<>();

    private static final int[][] BLD_CELLS = {{4, 5}, {7, 5}, {5, 8}};
    private static final int[][] OPEN_CELLS = {{3, 3}, {8, 3}, {3, 8}, {8, 8}, {6, 6}};
    private static final int[][] TOWER_CELLS = {{3, 3}, {5, 5}, {3, 5}};

    private static void zone(String id, String label, int li, int lj, int[][] cells, int[] npc) {
        ZONES.put(id, new Zone(id, label, li, lj, cells, npc));
    }

    static {
        zone("camp", "Южный пост", 2, 4, new int[][]{{3, 8}, {8, 8}, {3, 3}}, new int[]{8, 6});
        zone("gate", "Южная улица", 2, 3, OPEN_CELLS, null);
        zone("plaza", "Центральная площадь", 2, 2, new int[][]{{2, 2}, {9, 2}, {2, 9}, {9, 9}, {6, 2}, {6, 10}}, null);
        zone("nplaza", "Северный проспект", 2, 1, OPEN_CELLS, null);
        zone("tower", "Радиовышка", 2, 0, TOWER_CELLS, new int[]{4, 4});
        zone("hospital", "Больница", 0, 1, BLD_CELLS, null);
        zone("police", "Полицейский участок", 4, 1, BLD_CELLS, new int[]{6, 6});
        zone("warehouse", "Склад", 0, 3, BLD_CELLS, null);
        zone("shop", "Магазин", 4, 3, BLD_CELLS, null);
        zone("bunker", "Бункер", 4, 0, BLD_CELLS, null);
        zone("lab", "Лаборатория", 1, 1, BLD_CELLS, null);
        zone("gas", "АЗС", 1, 3, BLD_CELLS, null);
        zone("school", "Школа", 3, 3, BLD_CELLS, null);
        NPC_AT.put("camp", "old_sam");
        NPC_AT.put("tower", "radio_nina");
        NPC_AT.put("police", "captain_vance");
    }

    public final int ox;
    public final int oy;
    public final int oz;

    public City(int ox, int oy, int oz) {
        this.ox = ox;
        this.oy = oy;
        this.oz = oz;
    }

    /** Центр лагеря = позиция игрока при старте. */
    public static City startingAt(int px, int py, int pz) {
        return new City(px - (ROAD + PITCH * 2 + 6), py, pz - (ROAD + PITCH * 4 + 8));
    }

    public static City of(Player p) {
        CompoundTag d = StoryManager.data(p);
        if (!d.contains("cx")) return null;
        return new City(d.getInt("cx"), d.getInt("cy"), d.getInt("cz"));
    }

    // ---------- позиции ----------

    private int lotMinX(int li) {
        return ox + ROAD + PITCH * li;
    }

    private int lotMinZ(int lj) {
        return oz + ROAD + PITCH * lj;
    }

    public BlockPos at(int li, int lj, int cx, int cz) {
        return new BlockPos(lotMinX(li) + cx, oy, lotMinZ(lj) + cz);
    }

    public BlockPos playerSpawn() {
        return at(2, 4, 6, 8);
    }

    /** Безопасная точка для телепорта и стрелки. */
    public BlockPos safePos(String zoneId) {
        if (zoneId.equals("camp")) return playerSpawn();
        Zone z = ZONES.get(zoneId);
        int[] c = z.cells()[0];
        return at(z.li(), z.lj(), c[0], c[1]);
    }

    private static String lotType(int li, int lj) {
        for (Zone z : ZONES.values()) {
            if (z.li() == li && z.lj() == lj) return z.id();
        }
        return "gen";
    }

    // ---------- генерация ----------

    private BlockState surface(int dx, int dz, Random r) {
        boolean road = dx % PITCH < ROAD || dz % PITCH < ROAD;
        float f = r.nextFloat();
        if (road) {
            if (f < 0.07f) return Blocks.COBBLESTONE.defaultBlockState();
            if (f < 0.12f) return Blocks.COARSE_DIRT.defaultBlockState();
            return Blocks.GRAY_CONCRETE.defaultBlockState();
        }
        String t = lotType((dx - ROAD) / PITCH, (dz - ROAD) / PITCH);
        if (t.equals("camp")) {
            return f < 0.25f ? Blocks.PODZOL.defaultBlockState() : Blocks.COARSE_DIRT.defaultBlockState();
        }
        if (t.equals("plaza")) {
            return f < 0.12f ? Blocks.ANDESITE.defaultBlockState() : Blocks.POLISHED_ANDESITE.defaultBlockState();
        }
        if (f < 0.1f) return Blocks.COBBLESTONE.defaultBlockState();
        if (f < 0.3f) return Blocks.ANDESITE.defaultBlockState();
        return Blocks.STONE.defaultBlockState();
    }

    /** Выравнивает и очищает один столбец города. */
    public void column(ServerLevel level, int idx, Random r) {
        int dx = idx % SIZE;
        int dz = idx / SIZE;
        int x = ox + dx;
        int z = oz + dz;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        level.setBlock(m.set(x, oy - 1, z), surface(dx, dz, r), 2);
        for (int y = oy - 2; y >= oy - 4; y--) {
            m.set(x, y, z);
            BlockState s = level.getBlockState(m);
            if (s.isAir() || !s.getFluidState().isEmpty()) {
                level.setBlock(m, Blocks.STONE.defaultBlockState(), 2);
            }
        }
        for (int y = oy; y < oy + CLEAR_H; y++) {
            m.set(x, y, z);
            if (!level.getBlockState(m).isAir()) {
                level.setBlock(m, Blocks.AIR.defaultBlockState(), 2);
            }
        }
    }

    public void plan(Random r, List<Put> puts, List<Consumer<ServerLevel>> post) {
        for (int li = 0; li < N; li++) {
            for (int lj = 0; lj < N; lj++) {
                String t = lotType(li, lj);
                int bx = lotMinX(li);
                int bz = lotMinZ(lj);
                switch (t) {
                    case "camp" -> camp(puts, post, r, bx, bz);
                    case "plaza" -> plaza(puts, r, bx, bz);
                    case "gate", "nplaza" -> openLot(puts, r, bx, bz);
                    case "tower" -> tower(puts, post, r, bx, bz);
                    case "bunker" -> building(puts, post, r, bx, bz, 12, 12, 1,
                            pal(Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.STONE_BRICKS, Blocks.DEEPSLATE_BRICKS),
                            0.03f, List.of(new ItemStack(Items.IRON_CHESTPLATE), new ItemStack(Items.IRON_LEGGINGS),
                                    new ItemStack(Items.IRON_HELMET), new ItemStack(Items.IRON_BOOTS),
                                    new ItemStack(Items.GOLDEN_APPLE, 3), new ItemStack(LastFrontier.MEDKIT.get(), 2)),
                            false, BLD_CELLS);
                    case "lab" -> building(puts, post, r, bx, bz, 12, 11, 2,
                            pal(Blocks.WHITE_CONCRETE, Blocks.CYAN_TERRACOTTA, Blocks.LIGHT_GRAY_CONCRETE),
                            0.3f, List.of(new ItemStack(LastFrontier.MUTANT_SAMPLE.get())), true, BLD_CELLS);
                    case "gas" -> building(puts, post, r, bx, bz, 11, 10, 1,
                            pal(Blocks.RED_TERRACOTTA, Blocks.WHITE_CONCRETE, Blocks.GRAY_CONCRETE),
                            0.2f, List.of(new ItemStack(LastFrontier.FUEL_CANISTER.get(), 2)), false, BLD_CELLS);
                    case "school" -> building(puts, post, r, bx, bz, 12, 12, 2,
                            pal(Blocks.YELLOW_TERRACOTTA, Blocks.BRICKS, Blocks.TERRACOTTA),
                            0.25f, List.of(new ItemStack(LastFrontier.SCHEMATIC.get())), true, BLD_CELLS);
                    case "hospital" -> building(puts, post, r, bx, bz, 12, 11, 2,
                            pal(Blocks.WHITE_CONCRETE, Blocks.LIGHT_GRAY_CONCRETE, Blocks.WHITE_TERRACOTTA),
                            0.25f, List.of(new ItemStack(LastFrontier.BATTERY.get()),
                                    new ItemStack(LastFrontier.MEDKIT.get(), 1)), true, BLD_CELLS);
                    case "police" -> building(puts, post, r, bx, bz, 12, 12, 2,
                            pal(Blocks.BLUE_TERRACOTTA, Blocks.GRAY_CONCRETE, Blocks.LIGHT_BLUE_TERRACOTTA),
                            0.2f, List.of(new ItemStack(LastFrontier.KEYCARD.get())), true, BLD_CELLS);
                    case "warehouse" -> building(puts, post, r, bx, bz, 12, 12, 1,
                            pal(Blocks.GRAY_CONCRETE, Blocks.POLISHED_ANDESITE, Blocks.STONE),
                            0.2f, List.of(new ItemStack(LastFrontier.FUSE.get())), false, BLD_CELLS);
                    case "shop" -> building(puts, post, r, bx, bz, 11, 11, 1,
                            pal(Blocks.ORANGE_TERRACOTTA, Blocks.BRICKS, Blocks.TERRACOTTA),
                            0.2f, List.of(new ItemStack(LastFrontier.MEDKIT.get(), 2)), false, BLD_CELLS);
                    default -> general(puts, post, r, bx, bz);
                }
            }
        }
        streetProps(puts, r);
    }

    private static BlockState[] pal(Block... blocks) {
        BlockState[] out = new BlockState[blocks.length];
        for (int i = 0; i < blocks.length; i++) out[i] = blocks[i].defaultBlockState();
        return out;
    }

    private static void put(List<Put> puts, int x, int y, int z, BlockState s) {
        puts.add(new Put(new BlockPos(x, y, z), s));
    }

    private static final BlockState[][] GENERAL_PALETTES = {
            pal(Blocks.BRICKS, Blocks.STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS),
            pal(Blocks.GRAY_CONCRETE, Blocks.LIGHT_GRAY_CONCRETE, Blocks.STONE),
            pal(Blocks.ORANGE_TERRACOTTA, Blocks.TERRACOTTA, Blocks.BRICKS),
            pal(Blocks.LIGHT_GRAY_CONCRETE, Blocks.ANDESITE, Blocks.POLISHED_ANDESITE),
            pal(Blocks.MOSSY_STONE_BRICKS, Blocks.STONE_BRICKS, Blocks.COBBLESTONE)
    };

    private void general(List<Put> puts, List<Consumer<ServerLevel>> post, Random r, int bx, int bz) {
        int w = 10 + r.nextInt(3);
        int d = 10 + r.nextInt(3);
        int floors = r.nextInt(3) == 0 ? 2 : 1;
        BlockState[] p = GENERAL_PALETTES[r.nextInt(GENERAL_PALETTES.length)];
        building(puts, post, r, bx, bz, w, d, floors, p, 0.25f, List.of(), false, BLD_CELLS);
    }

    // ---------- здания ----------

    private static boolean reserved(int x, int z, int w, int d, int[][] keep, boolean stairs) {
        if (stairs && x <= 2 && z <= 7) return true;
        for (int[] k : keep) {
            if (Math.abs(x - k[0]) <= 1 && Math.abs(z - k[1]) <= 1) return true;
        }
        if (Math.abs(x - (w - 2)) <= 1 && (z <= 2 || z >= d - 3)) return true;
        if ((x == w / 2 - 1 || x == w / 2) && z >= d - 3) return true;
        if (x == w / 2 && z <= 2) return true;
        return x == 2 && z == d - 3;
    }

    private void building(List<Put> puts, List<Consumer<ServerLevel>> post, Random r, int bx, int bz,
                          int w, int d, int floors, BlockState[] pal, float ruin,
                          List<ItemStack> quest, boolean questUp, int[][] keep) {
        BlockState glass = Blocks.LIGHT_GRAY_STAINED_GLASS.defaultBlockState();

        // стены
        for (int f = 0; f < floors; f++) {
            int base = oy + f * 5;
            float rr = ruin * (f == 0 ? 0.5f : 1.3f);
            for (int x = 0; x < w; x++) {
                for (int z = 0; z < d; z++) {
                    boolean edge = x == 0 || z == 0 || x == w - 1 || z == d - 1;
                    if (!edge) continue;
                    for (int dy = 0; dy < 4; dy++) {
                        if (f == 0 && z == d - 1 && (x == w / 2 || x == w / 2 - 1) && dy < 3) continue;
                        if (f == 0 && z == 0 && x == w / 2 && dy < 2) continue;
                        boolean window = (dy == 1 || dy == 2)
                                && (((z == 0 || z == d - 1) && x % 3 == 1) || ((x == 0 || x == w - 1) && z % 3 == 1));
                        if (window) {
                            if (r.nextFloat() < 0.55f) continue;
                            put(puts, bx + x, base + dy, bz + z, glass);
                            continue;
                        }
                        if (r.nextFloat() < rr * (0.4f + 0.2f * dy)) continue;
                        put(puts, bx + x, base + dy, bz + z, pal[r.nextInt(pal.length)]);
                    }
                }
            }
        }

        // перекрытия и крыша
        for (int f = 0; f < floors; f++) {
            int y = oy + f * 5 + 4;
            boolean roof = f == floors - 1;
            for (int x = 0; x < w; x++) {
                for (int z = 0; z < d; z++) {
                    if (floors > 1 && f == 0 && x == 1 && z >= 3 && z <= 5) continue; // проём лестницы
                    boolean forced = floors > 1 && f == 0 && questUp && x == w - 2 && z == 1;
                    float chance = roof ? 0.72f : 0.97f;
                    if (forced || r.nextFloat() < chance) {
                        put(puts, bx + x, y, bz + z, pal[r.nextInt(pal.length)]);
                    }
                }
            }
        }

        // лестница на второй этаж
        if (floors > 1) {
            BlockState st = Blocks.STONE_BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.SOUTH);
            BlockState solid = Blocks.STONE_BRICKS.defaultBlockState();
            for (int i = 0; i < 5; i++) {
                int sx = bx + 1;
                int sz = bz + 1 + i;
                for (int k = 0; k < i; k++) put(puts, sx, oy + k, sz, solid);
                put(puts, sx, oy + i, sz, st);
            }
        }

        // фонарь и завалы
        put(puts, bx + 2, oy, bz + d - 3, Blocks.LANTERN.defaultBlockState());
        BlockState[] rubble = pal(Blocks.COBBLESTONE, Blocks.MOSSY_COBBLESTONE, Blocks.CRACKED_STONE_BRICKS, Blocks.STONE_BRICKS);
        for (int n = 0; n < 7; n++) {
            int rx = 2 + r.nextInt(Math.max(1, w - 4));
            int rz = 2 + r.nextInt(Math.max(1, d - 4));
            if (reserved(rx, rz, w, d, keep, floors > 1)) continue;
            int h = 1 + r.nextInt(2);
            for (int dy = 0; dy < h; dy++) {
                put(puts, bx + rx, oy + dy, bz + rz, rubble[r.nextInt(rubble.length)]);
            }
        }

        decorate(puts, r, bx, bz, w, d, floors > 1, keep);

        // сундуки
        BlockPos nearNorth = new BlockPos(bx + w - 2, oy, bz + 1);
        BlockPos nearSouth = new BlockPos(bx + w - 2, oy, bz + d - 2);
        chest(puts, post, nearSouth, Direction.NORTH, List.of(), r);
        if (quest.isEmpty()) {
            chest(puts, post, nearNorth, Direction.SOUTH, List.of(), r);
        } else if (questUp && floors > 1) {
            chest(puts, post, nearNorth, Direction.SOUTH, List.of(), r);
            chest(puts, post, new BlockPos(bx + w - 2, oy + 5, bz + 1), Direction.SOUTH, quest, r);
        } else {
            chest(puts, post, nearNorth, Direction.SOUTH, quest, r);
        }
    }

    private static final Item[] JUNK = {
            Items.BREAD, Items.COOKED_BEEF, Items.APPLE, Items.CARROT, Items.IRON_NUGGET, Items.COAL,
            Items.GUNPOWDER, Items.FLINT, Items.STRING, Items.LEATHER, Items.PAPER, Items.STICK,
            Items.TORCH, Items.GLASS_BOTTLE
    };

    private void chest(List<Put> puts, List<Consumer<ServerLevel>> post, BlockPos pos, Direction facing,
                       List<ItemStack> fixed, Random r) {
        puts.add(new Put(pos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing)));
        long seed = r.nextLong();
        List<ItemStack> copy = new ArrayList<>();
        for (ItemStack s : fixed) copy.add(s.copy());
        post.add(lv -> {
            BlockEntity be = lv.getBlockEntity(pos);
            if (!(be instanceof ChestBlockEntity c)) return;
            Random rr = new Random(seed);
            for (ItemStack s : copy) {
                int slot = rr.nextInt(27);
                while (!c.getItem(slot).isEmpty()) slot = (slot + 1) % 27;
                c.setItem(slot, s.copy());
            }
            int n = 3 + rr.nextInt(4);
            for (int i = 0; i < n; i++) {
                int slot = rr.nextInt(27);
                if (!c.getItem(slot).isEmpty()) continue;
                c.setItem(slot, new ItemStack(JUNK[rr.nextInt(JUNK.length)], 1 + rr.nextInt(4)));
            }
            if (rr.nextFloat() < 0.4f) {
                int slot = rr.nextInt(27);
                if (c.getItem(slot).isEmpty()) {
                    c.setItem(slot, new ItemStack(LastFrontier.NOTES.get(rr.nextInt(LastFrontier.NOTES.size())).get()));
                }
            }
        });
    }

    /** Мебель и мусор внутри здания (первый этаж). */
    private void decorate(List<Put> puts, Random r, int bx, int bz, int w, int d, boolean stairs, int[][] keep) {
        for (int n = 0; n < 9; n++) {
            int x = 2 + r.nextInt(Math.max(1, w - 4));
            int z = 2 + r.nextInt(Math.max(1, d - 4));
            if (reserved(x, z, w, d, keep, stairs)) continue;
            int type = r.nextInt(6);
            switch (type) {
                case 0 -> put(puts, bx + x, oy, bz + z, Blocks.BARREL.defaultBlockState());
                case 1 -> {
                    put(puts, bx + x, oy, bz + z, Blocks.BOOKSHELF.defaultBlockState());
                    put(puts, bx + x, oy + 1, bz + z, Blocks.BOOKSHELF.defaultBlockState());
                }
                case 2 -> put(puts, bx + x, oy, bz + z, Blocks.CRAFTING_TABLE.defaultBlockState());
                case 3 -> put(puts, bx + x, oy + 3, bz + z, Blocks.COBWEB.defaultBlockState());
                case 4 -> put(puts, bx + x, oy, bz + z, Blocks.OAK_SLAB.defaultBlockState());
                default -> put(puts, bx + x, oy, bz + z, Blocks.CAULDRON.defaultBlockState());
            }
        }
    }

    /** Фонари на перекрёстках и брошенные машины на дорогах. */
    private void streetProps(List<Put> puts, Random r) {
        for (int i = 0; i <= N; i++) {
            for (int j = 0; j <= N; j++) {
                if (r.nextFloat() < 0.6f) {
                    int x = ox + PITCH * i;
                    int z = oz + PITCH * j;
                    if (x >= ox + SIZE || z >= oz + SIZE) continue;
                    for (int dy = 0; dy < 4; dy++) put(puts, x, oy + dy, z, Blocks.OAK_FENCE.defaultBlockState());
                    put(puts, x, oy + 4, z, Blocks.LANTERN.defaultBlockState());
                }
            }
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j <= N; j++) {
                if (r.nextFloat() < 0.4f) {
                    int z = oz + PITCH * j + 1;
                    if (z + 1 >= oz + SIZE) continue;
                    car(puts, r, ox + PITCH * i + ROAD + 2 + r.nextInt(4), z);
                }
            }
        }
        for (int i = 0; i <= N; i++) {
            for (int j = 0; j < N; j++) {
                if (r.nextFloat() < 0.4f) {
                    int x = ox + PITCH * i + 1;
                    if (x + 1 >= ox + SIZE) continue;
                    carVertical(puts, r, x, oz + PITCH * j + ROAD + 2 + r.nextInt(4));
                }
            }
        }
    }

    private void carVertical(List<Put> puts, Random r, int x, int z) {
        Block[] colors = {Blocks.RED_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.BLACK_CONCRETE, Blocks.WHITE_CONCRETE,
                Blocks.GRAY_CONCRETE};
        BlockState body = colors[r.nextInt(colors.length)].defaultBlockState();
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 4; j++) {
                put(puts, x + i, oy, z + j, body);
                if (j == 1 || j == 2) put(puts, x + i, oy + 1, z + j, Blocks.GRAY_STAINED_GLASS.defaultBlockState());
            }
        }
    }

    // ---------- особые лоты ----------

    private void camp(List<Put> puts, List<Consumer<ServerLevel>> post, Random r, int bx, int bz) {
        BlockState sand = Blocks.SMOOTH_SANDSTONE.defaultBlockState();
        for (int x = 1; x <= 10; x++) {
            for (int z = 1; z <= 10; z++) {
                boolean edge = x == 1 || x == 10 || z == 1 || z == 10;
                if (!edge) continue;
                if ((z == 1 || z == 10) && (x == 5 || x == 6)) continue; // ворота
                int h = (x + z) % 3 == 0 ? 1 : 2;
                for (int dy = 0; dy < h; dy++) put(puts, bx + x, oy + dy, bz + z, sand);
            }
        }
        put(puts, bx + 6, oy, bz + 6, Blocks.CAMPFIRE.defaultBlockState());

        BlockState wool = Blocks.GREEN_WOOL.defaultBlockState();
        for (int x = 2; x <= 4; x++) {
            for (int z = 2; z <= 4; z++) {
                boolean center = x == 3 && z == 3;
                boolean door = x == 3 && z == 4;
                for (int dy = 0; dy < 2; dy++) {
                    if (!center && !door) put(puts, bx + x, oy + dy, bz + z, wool);
                }
                put(puts, bx + x, oy + 2, bz + z, wool);
            }
        }
        chest(puts, post, new BlockPos(bx + 3, oy, bz + 3), Direction.SOUTH,
                List.of(new ItemStack(Items.COOKED_BEEF, 8), new ItemStack(Items.BREAD, 6)), r);

        put(puts, bx + 8, oy, bz + 3, Blocks.CRAFTING_TABLE.defaultBlockState());
        put(puts, bx + 9, oy, bz + 3, Blocks.FURNACE.defaultBlockState());
        put(puts, bx + 8, oy, bz + 9, Blocks.BARREL.defaultBlockState());
        put(puts, bx + 9, oy, bz + 9, Blocks.BARREL.defaultBlockState());
        for (int[] lp : new int[][]{{2, 9}, {9, 2}}) {
            put(puts, bx + lp[0], oy, bz + lp[1], Blocks.OAK_FENCE.defaultBlockState());
            put(puts, bx + lp[0], oy + 1, bz + lp[1], Blocks.OAK_FENCE.defaultBlockState());
            put(puts, bx + lp[0], oy + 2, bz + lp[1], Blocks.LANTERN.defaultBlockState());
        }
    }

    private void plaza(List<Put> puts, Random r, int bx, int bz) {
        BlockState sb = Blocks.STONE_BRICKS.defaultBlockState();
        for (int x = 5; x <= 7; x++) for (int z = 5; z <= 7; z++) put(puts, bx + x, oy, bz + z, sb);
        for (int dy = 1; dy <= 5; dy++) {
            put(puts, bx + 6, oy + dy, bz + 6, Blocks.STONE_BRICK_WALL.defaultBlockState());
        }
        BlockState cover = Blocks.GRAY_CONCRETE.defaultBlockState();
        for (int[] seg : new int[][]{{3, 4}, {7, 4}, {3, 8}, {7, 8}}) {
            for (int k = 0; k < 3; k++) {
                if (r.nextFloat() < 0.15f) continue;
                int h = 1 + r.nextInt(2);
                for (int dy = 0; dy < h; dy++) put(puts, bx + seg[0] + k, oy + dy, bz + seg[1], cover);
            }
        }
    }

    private void car(List<Put> puts, Random r, int x, int z) {
        Block[] colors = {Blocks.RED_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.BLACK_CONCRETE, Blocks.WHITE_CONCRETE,
                Blocks.GRAY_CONCRETE};
        BlockState body = colors[r.nextInt(colors.length)].defaultBlockState();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 2; j++) {
                put(puts, x + i, oy, z + j, body);
                if (i == 1 || i == 2) put(puts, x + i, oy + 1, z + j, Blocks.GRAY_STAINED_GLASS.defaultBlockState());
            }
        }
    }

    private void openLot(List<Put> puts, Random r, int bx, int bz) {
        car(puts, r, bx + 2, bz + 5);
        car(puts, r, bx + 7, bz + 5);
    }

    private void tower(List<Put> puts, List<Consumer<ServerLevel>> post, Random r, int bx, int bz) {
        building(puts, post, r, bx, bz, 8, 8, 1,
                pal(Blocks.LIGHT_GRAY_CONCRETE, Blocks.GRAY_CONCRETE, Blocks.ANDESITE),
                0.15f, List.of(), false, TOWER_CELLS);
        BlockState bar = Blocks.IRON_BARS.defaultBlockState();
        int[][] pil = {{8, 8}, {11, 8}, {8, 11}, {11, 11}};
        for (int[] p : pil) {
            for (int dy = 0; dy < 20; dy++) put(puts, bx + p[0], oy + dy, bz + p[1], bar);
            put(puts, bx + p[0], oy + 20, bz + p[1], Blocks.LIGHTNING_ROD.defaultBlockState());
        }
        for (int ring : new int[]{4, 9, 14, 19}) {
            for (int i = 9; i <= 10; i++) {
                put(puts, bx + i, oy + ring, bz + 8, bar);
                put(puts, bx + i, oy + ring, bz + 11, bar);
                put(puts, bx + 8, oy + ring, bz + i, bar);
                put(puts, bx + 11, oy + ring, bz + i, bar);
            }
        }
    }

    // ---------- существа ----------

    /** Расставляет NPC в их зонах (один раз за город). */
    public void spawnNpcs(ServerLevel level) {
        for (Map.Entry<String, String> e : NPC_AT.entrySet()) {
            Zone z = ZONES.get(e.getKey());
            Npcs.spawn(level, e.getValue(), at(z.li(), z.lj(), z.npc()[0], z.npc()[1]));
        }
    }

    /** Фоновые враги в обычных кварталах: город не пустой. */
    public void spawnAmbient(ServerLevel level, Random r) {
        String[] kinds = {"mutant", "scav", "raider", "mutant"};
        for (int li = 0; li < N; li++) {
            for (int lj = 0; lj < N - 1; lj++) {
                if (!lotType(li, lj).equals("gen")) continue;
                if (r.nextFloat() > 0.6f) continue;
                int n = 1 + r.nextInt(2);
                for (int k = 0; k < n; k++) {
                    int[] c = BLD_CELLS[k % BLD_CELLS.length];
                    spawnOne(level, RaiderKind.byId(kinds[r.nextInt(kinds.length)]), at(li, lj, c[0], c[1]), "lf_ambient");
                }
            }
        }
    }

    /** Спавн врагов квеста. Позиции берутся из клеток зоны, а не из воздуха рядом с игроком. */
    public void spawnAll(ServerLevel level, List<Quest.Spawn> spawns) {
        Map<String, Integer> counters = new HashMap<>();
        for (Quest.Spawn s : spawns) {
            Zone z = ZONES.get(s.zone());
            if (z == null) continue;
            RaiderKind kind = RaiderKind.byId(s.kind());
            for (int i = 0; i < s.count(); i++) {
                int n = counters.merge(s.zone(), 1, Integer::sum) - 1;
                int[] c = z.cells()[n % z.cells().length];
                int extra = n / z.cells().length;
                spawnOne(level, kind, at(z.li(), z.lj(), c[0] + extra, c[1]), s.tag());
            }
        }
    }

    /** Патруль Шакалов появляется в дальних кварталах, чтобы город не затихал. */
    public void spawnPatrol(ServerLevel level, Player player) {
        AABB area = new AABB(player.blockPosition()).inflate(110);
        List<RaiderEntity> alive = level.getEntitiesOfClass(RaiderEntity.class, area, e -> e.getTags().contains("lf_patrol"));
        if (alive.size() >= 5) return;
        Random r = new Random();
        for (int attempt = 0; attempt < 12; attempt++) {
            int li = r.nextInt(N);
            int lj = r.nextInt(N - 1);
            if (!lotType(li, lj).equals("gen")) continue;
            BlockPos c = at(li, lj, 6, 6);
            double dx = c.getX() - player.getX();
            double dz = c.getZ() - player.getZ();
            if (Math.hypot(dx, dz) < 40) continue;
            String[] kinds = {"raider", "scav", "runner", "raider"};
            int n = 2 + r.nextInt(2);
            for (int k = 0; k < n; k++) {
                int[] cell = BLD_CELLS[k % BLD_CELLS.length];
                spawnOne(level, RaiderKind.byId(kinds[r.nextInt(kinds.length)]), at(li, lj, cell[0], cell[1]), "lf_patrol");
            }
            return;
        }
    }

    private void spawnOne(ServerLevel level, RaiderKind kind, BlockPos base, String tag) {
        RaiderEntity e = LastFrontier.RAIDER.get().create(level);
        if (e == null) return;
        BlockPos p = base.above();
        for (int dy = 0; dy < 4; dy++) {
            e.setPos(base.getX() + 0.5, base.getY() + dy, base.getZ() + 0.5);
            if (level.noCollision(e)) {
                p = base.above(dy);
                break;
            }
        }
        e.moveTo(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, level.random.nextFloat() * 360f, 0f);
        e.setKind(kind);
        e.setPersistenceRequired();
        e.addTag(tag);
        if (kind.boss) {
            e.setCustomName(Component.literal(kind.label));
            e.setCustomNameVisible(true);
            e.setGlowingTag(true);
        }
        e.restrictTo(p, 20);
        level.addFreshEntity(e);
    }
}
