package com.lastfrontier;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;

import java.util.LinkedHashMap;
import java.util.Map;

/** NPC истории: имена, реплики и спавн. Скин берётся из id (textures/entity/<id>.png). */
public final class Npcs {
    public static final String TAG_PREFIX = "lf_npc_";

    public static final Map<String, String> NAMES = new LinkedHashMap<>();
    public static final Map<String, String> IDLE = new LinkedHashMap<>();

    static {
        add("old_sam", "Старый Сэм",
                "Занят делом, выживший. Загляни, когда выполнишь задание.");
        add("radio_nina", "Нина-радистка",
                "Эфир шипит... Я слушаю. Возвращайся, когда будут новости.");
        add("captain_vance", "Капитан Вэнс",
                "Не мешай. У тебя есть приказ - выполняй.");
    }

    private static void add(String id, String name, String idle) {
        NAMES.put(id, name);
        IDLE.put(id, idle);
    }

    public static SurvivorEntity spawn(ServerLevel level, String id, BlockPos pos) {
        SurvivorEntity e = LastFrontier.SURVIVOR.get().create(level);
        if (e == null) return null;
        e.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0f, 0f);
        e.setSkin(id);
        e.setNoAi(true);
        e.setInvulnerable(true);
        e.setPersistenceRequired();
        e.setSilent(true);
        e.setCustomName(Component.literal(NAMES.getOrDefault(id, id)));
        e.setCustomNameVisible(true);
        e.addTag(TAG_PREFIX + id);
        level.addFreshEntity(e);
        return e;
    }

    private Npcs() {}
}
