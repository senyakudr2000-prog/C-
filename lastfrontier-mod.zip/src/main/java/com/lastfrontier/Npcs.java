package com.lastfrontier;

import java.util.LinkedHashMap;
import java.util.Map;

/** NPC истории. Это обычные безмозглые жители с тегом lf_npc_<id>. */
public final class Npcs {
    public static final String TAG_PREFIX = "lf_npc_";

    public static final Map<String, String> NAMES = new LinkedHashMap<>();
    public static final Map<String, String> IDLE = new LinkedHashMap<>();

    static {
        add("old_sam", "Старый Сэм",
                "Занят делом, выживший. Загляни, когда выполнишь задание.");
        add("radio_nina", "Нина-радистка",
                "Эфир шипит... Я слушаю. Возвращайся, когда будут новости.");
        add("captain_vance", "Капитан Вэнс",
                "Не мешай. У тебя есть приказ - выполняй.");
    }

    private static void add(String id, String name, String idle) {
        NAMES.put(id, name);
        IDLE.put(id, idle);
    }

    private Npcs() {}
}
