package com.lastfrontier;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = LastFrontier.MODID)
public final class StoryEvents {

    private static final String[] DIRS = {"С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ"};

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            StoryManager.loadDifficulty(sp);
            StoryManager.begin(sp);
        }
    }

    /** Прогресс не должен пропадать после смерти. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        var old = e.getOriginal().getPersistentData();
        if (old.contains(StoryManager.KEY)) {
            e.getEntity().getPersistentData().put(StoryManager.KEY, old.getCompound(StoryManager.KEY).copy());
        }
    }

    @SubscribeEvent
    public static void onKill(LivingDeathEvent e) {
        Entity killer = e.getSource().getEntity();
        if (!(killer instanceof ServerPlayer sp)) return;
        if (!StoryManager.isReady(sp)) return;
        Quest q = StoryManager.current(sp);
        if (q == null) return;
        LivingEntity dead = e.getEntity();
        Quest.Objective o = q.objective();
        if (o.type() == Quest.Type.KILL) {
            String id = BuiltInRegistries.ENTITY_TYPE.getKey(dead.getType()).toString();
            if (id.equals(o.target())) StoryManager.addProgress(sp, 1);
        } else if (o.type() == Quest.Type.KILL_TAG) {
            if (dead.getTags().contains(o.target())) StoryManager.addProgress(sp, 1);
        }
    }

    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (e.getHand() != InteractionHand.MAIN_HAND) return;

        String npcId = null;
        for (String tag : e.getTarget().getTags()) {
            if (tag.startsWith(Npcs.TAG_PREFIX)) {
                npcId = tag.substring(Npcs.TAG_PREFIX.length());
                break;
            }
        }
        if (npcId == null) return;

        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);

        String name = Npcs.NAMES.getOrDefault(npcId, npcId);
        Quest q = StoryManager.current(sp);
        if (q != null && q.objective().type() == Quest.Type.TALK && q.objective().target().equals(npcId)) {
            for (String line : q.objective().dialogue()) {
                sp.sendSystemMessage(Component.literal("§e[" + name + "] §f" + line));
            }
            StoryManager.addProgress(sp, 1);
        } else {
            sp.sendSystemMessage(Component.literal("§e[" + name + "] §f" + Npcs.IDLE.getOrDefault(npcId, "...")));
        }
    }

    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (sp.tickCount % 20 != 0) return;

        if (!StoryManager.isStarted(sp)) {
            StoryManager.begin(sp);
            return;
        }
        if (!StoryManager.isReady(sp)) {
            StoryManager.resume(sp);
            return;
        }
        // патрули Шакалов: раз в ~90 секунд, после второго квеста, не в мирном режиме
        if (StoryManager.index(sp) >= 2 && sp.level().getDifficulty() != Difficulty.PEACEFUL) {
            var pd = StoryManager.data(sp);
            int t = pd.getInt("patrol") + 1;
            if (t >= 90) {
                t = 0;
                City pc = City.of(sp);
                if (pc != null) pc.spawnPatrol(sp.serverLevel(), sp);
            }
            pd.putInt("patrol", t);
        }

        Quest q = StoryManager.current(sp);
        if (q == null) return;
        Quest.Objective o = q.objective();

        if (o.type() == Quest.Type.COLLECT) {
            String target = o.target();
            int total = 0;
            for (ItemStack s : sp.getInventory().items) {
                if (!s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).toString().equals(target)) {
                    total += s.getCount();
                }
            }
            int shown = Math.min(total, o.count());
            StoryManager.setProgress(sp, shown);
            if (total >= o.count()) {
                StoryManager.complete(sp);
                return;
            }
        } else if (o.type() == Quest.Type.TRAVEL) {
            var d = StoryManager.data(sp);
            double dist = Math.hypot(sp.getX() - d.getDouble("sx"), sp.getZ() - d.getDouble("sz"));
            StoryManager.setProgress(sp, (int) Math.min(dist, o.count()));
            if (dist >= o.count()) {
                StoryManager.complete(sp);
                return;
            }
        }

        // подсказка-стрелка к цели раз в 2 секунды
        if (sp.tickCount % 40 == 0 && q.zone() != null) {
            City city = City.of(sp);
            if (city != null) {
                BlockPos t = city.safePos(q.zone());
                double dx = t.getX() + 0.5 - sp.getX();
                double dz = t.getZ() + 0.5 - sp.getZ();
                int dist = (int) Math.hypot(dx, dz);
                double bearing = Math.toDegrees(Math.atan2(dx, -dz));
                int di = (int) Math.round(((bearing % 360) + 360) % 360 / 45.0) % 8;
                sp.displayClientMessage(Component.literal("§e" + q.title() + " §f"
                        + StoryManager.progress(sp) + "/" + o.count()
                        + " §7| цель: " + City.ZONES.get(q.zone()).label() + " §f" + dist + " м " + DIRS[di]), true);
            }
        }
    }

    private StoryEvents() {}
}
