package com.lastfrontier;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = LastFrontier.MODID)
public final class StoryEvents {

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            StoryManager.begin(sp);
        }
    }

    /** Прогресс не должен пропадать после смерти. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        var old = e.getOriginal().getPersistentData();
        if (old.contains(StoryManager.KEY)) {
            e.getEntity().getPersistentData().put(StoryManager.KEY, old.getCompound(StoryManager.KEY).copy());
        }
    }

    @SubscribeEvent
    public static void onKill(LivingDeathEvent e) {
        Entity killer = e.getSource().getEntity();
        if (!(killer instanceof ServerPlayer sp)) return;
        Quest q = StoryManager.current(sp);
        if (q == null) return;
        LivingEntity dead = e.getEntity();
        Quest.Objective o = q.objective();
        if (o.type() == Quest.Type.KILL) {
            String id = BuiltInRegistries.ENTITY_TYPE.getKey(dead.getType()).toString();
            if (id.equals(o.target())) StoryManager.addProgress(sp, 1);
        } else if (o.type() == Quest.Type.KILL_TAG) {
            if (dead.getTags().contains(o.target())) StoryManager.addProgress(sp, 1);
        }
    }

    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (e.getHand() != InteractionHand.MAIN_HAND) return;

        String npcId = null;
        for (String tag : e.getTarget().getTags()) {
            if (tag.startsWith(Npcs.TAG_PREFIX)) {
                npcId = tag.substring(Npcs.TAG_PREFIX.length());
                break;
            }
        }
        if (npcId == null) return;

        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);

        String name = Npcs.NAMES.getOrDefault(npcId, npcId);
        Quest q = StoryManager.current(sp);
        if (q != null && q.objective().type() == Quest.Type.TALK && q.objective().target().equals(npcId)) {
            for (String line : q.objective().dialogue()) {
                sp.sendSystemMessage(Component.literal("§e[" + name + "] §f" + line));
            }
            StoryManager.addProgress(sp, 1);
        } else {
            sp.sendSystemMessage(Component.literal("§e[" + name + "] §f" + Npcs.IDLE.getOrDefault(npcId, "...")));
        }
    }

    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (sp.tickCount % 20 != 0) return;

        if (!StoryManager.isStarted(sp)) {
            StoryManager.begin(sp);
            return;
        }
        Quest q = StoryManager.current(sp);
        if (q == null) return;
        Quest.Objective o = q.objective();

        if (o.type() == Quest.Type.COLLECT) {
            int total = 0;
            for (ItemStack s : sp.getInventory().items) {
                if (!s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).toString().equals(o.target())) {
                    total += s.getCount();
                }
            }
            int shown = Math.min(total, o.count());
            if (shown != StoryManager.progress(sp)) {
                StoryManager.setProgress(sp, shown);
                sp.displayClientMessage(Component.literal("§e" + q.title() + ": §f" + shown + "/" + o.count()), true);
            }
            if (total >= o.count()) StoryManager.complete(sp);

        } else if (o.type() == Quest.Type.TRAVEL) {
            var d = StoryManager.data(sp);
            double dist = Math.hypot(sp.getX() - d.getDouble("sx"), sp.getZ() - d.getDouble("sz"));
            int shown = (int) Math.min(dist, o.count());
            if (shown / 10 != StoryManager.progress(sp) / 10) {
                sp.displayClientMessage(Component.literal("§e" + q.title() + ": §f" + shown + "/" + o.count()), true);
            }
            StoryManager.setProgress(sp, shown);
            if (dist >= o.count()) StoryManager.complete(sp);
        }
    }

    private StoryEvents() {}
}
