package com.lastfrontier;

import net.minecraft.world.item.Item;

import java.util.function.Supplier;

/** Типы врагов: характеристики, оружие, поведение. */
public enum RaiderKind {
    //     id        название            hp   armor speed follow shots interval range acc   dmg  melee  оружие                                   boss  pitch
    SCAV("scav",     "Шакал",            20,  0,    0.26, 28,    1,    35,      16,   0.55, 3.0, 0,     () -> LastFrontier.PROP_PISTOL.get(),  false, 0.9f),
    RAIDER("raider", "Рейдер",           34,  4,    0.25, 32,    3,    40,      20,   0.50, 3.0, 0,     () -> LastFrontier.PROP_RIFLE.get(),   false, 0.7f),
    HEAVY("heavy",   "Тяжёлый",          70,  10,   0.21, 20,    6,    45,      9,    0.60, 2.5, 0,     () -> LastFrontier.PROP_SHOTGUN.get(), false, 0.5f),
    SNIPER("sniper", "Снайпер",          24,  0,    0.24, 44,    1,    70,      36,   0.80, 9.0, 0,     () -> LastFrontier.PROP_SNIPER.get(),  false, 0.4f),
    MUTANT("mutant", "Мутант",           36,  2,    0.32, 24,    0,    0,       0,    0.0,  0.0, 5.0,   null,                                  false, 1.0f),
    RUNNER("runner", "Бегун",            18,  0,    0.42, 28,    0,    0,       0,    0.0,  0.0, 3.5,   null,                                  false, 1.0f),
    BRUTE("brute",   "Громила",          130, 6,    0.24, 24,    0,    0,       0,    0.0,  0.0, 9.0,   null,                                  false, 1.0f),
    WARLORD("warlord", "Главарь Шакалов", 220, 12,  0.25, 32,    4,    38,      22,   0.50, 4.0, 0,     () -> LastFrontier.PROP_RIFLE.get(),   true,  0.6f),
    GENERAL("general", "Капитан Вэнс",   380, 16,   0.26, 36,    4,    34,      26,   0.55, 5.0, 0,     () -> LastFrontier.PROP_SNIPER.get(),  true,  0.5f);

    public final String id;
    public final String label;
    public final double hp;
    public final double armor;
    public final double speed;
    public final double follow;
    public final int shots;
    public final int interval;
    public final double range;
    public final double accuracy;
    public final double dmg;
    public final double meleeDmg;
    public final Supplier<Item> weapon;
    public final boolean boss;
    public final float soundPitch;

    RaiderKind(String id, String label, double hp, double armor, double speed, double follow, int shots,
               int interval, double range, double accuracy, double dmg, double meleeDmg,
               Supplier<Item> weapon, boolean boss, float soundPitch) {
        this.id = id;
        this.label = label;
        this.hp = hp;
        this.armor = armor;
        this.speed = speed;
        this.follow = follow;
        this.shots = shots;
        this.interval = interval;
        this.range = range;
        this.accuracy = accuracy;
        this.dmg = dmg;
        this.meleeDmg = meleeDmg;
        this.weapon = weapon;
        this.boss = boss;
        this.soundPitch = soundPitch;
    }

    public boolean melee() {
        return weapon == null;
    }

    public static RaiderKind byId(String id) {
        for (RaiderKind k : values()) {
            if (k.id.equals(id)) return k;
        }
        return SCAV;
    }
}
