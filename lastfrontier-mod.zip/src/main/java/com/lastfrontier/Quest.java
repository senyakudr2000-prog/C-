package com.lastfrontier;

import java.util.List;

/** Один квест истории. */
public record Quest(
        String id,
        String chapter,
        String title,
        String description,
        Objective objective,
        String zone,              // зона города, куда указывает стрелка (может быть null)
        List<Spawn> spawns,       // враги, которые появляются при старте квеста
        List<String> onStart,     // команды при старте
        List<String> onComplete,  // команды-награды
        String doneText) {

    public enum Type {
        TALK,      // поговорить с NPC (target = id NPC)
        KILL,      // убить N существ типа (target = minecraft:zombie)
        KILL_TAG,  // убить N существ с тегом (target = тег)
        COLLECT,   // иметь в инвентаре N предметов (target = lastfrontier:fuse)
        TRAVEL     // отойти на N блоков от точки старта квеста
    }

    public record Spawn(String kind, String zone, int count, String tag) {}

    public record Objective(Type type, String target, int count, List<String> dialogue) {
        public static Objective talk(String npc, List<String> dialogue) {
            return new Objective(Type.TALK, npc, 1, dialogue);
        }
        public static Objective kill(String entity, int n) {
            return new Objective(Type.KILL, entity, n, List.of());
        }
        public static Objective killTag(String tag, int n) {
            return new Objective(Type.KILL_TAG, tag, n, List.of());
        }
        public static Objective collect(String item, int n) {
            return new Objective(Type.COLLECT, item, n, List.of());
        }
        public static Objective travel(int blocks) {
            return new Objective(Type.TRAVEL, "", blocks, List.of());
        }
    }
}
