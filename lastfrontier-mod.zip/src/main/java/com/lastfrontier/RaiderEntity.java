package com.lastfrontier;

import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Враг с настоящим ИИ: ищет цель, держит дистанцию своего оружия, стреляет
 * только при прямой видимости (пули блокируются стенами), ходит по земле.
 * Тип определяется полем Kind (см. RaiderKind).
 */
public class RaiderEntity extends Monster implements RangedAttackMob {
    private static final EntityDataAccessor<String> KIND =
            SynchedEntityData.defineId(RaiderEntity.class, EntityDataSerializers.STRING);

    public RaiderEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ARMOR, 0.0)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.ATTACK_DAMAGE, 3.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(KIND, "scav");
    }

    public RaiderKind kind() {
        return RaiderKind.byId(this.entityData.get(KIND));
    }

    public String kindId() {
        return this.entityData.get(KIND);
    }

    public void setKind(RaiderKind k) {
        this.entityData.set(KIND, k.id);
        if (!this.level().isClientSide()) {
            applyKind(k, true);
        }
    }

    private void applyKind(RaiderKind k, boolean fresh) {
        float oldHp = getHealth();
        double maxHp = k.hp * StoryManager.hpMult;
        attr(Attributes.MAX_HEALTH, maxHp);
        attr(Attributes.MOVEMENT_SPEED, k.speed);
        attr(Attributes.ARMOR, k.armor);
        attr(Attributes.FOLLOW_RANGE, k.follow);
        attr(Attributes.ATTACK_DAMAGE, (k.meleeDmg > 0 ? k.meleeDmg : 3.0) * StoryManager.dmgMult);
        setHealth(fresh ? (float) maxHp : Math.min(oldHp, (float) maxHp));
        if (k.weapon != null) {
            setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(k.weapon.get()));
        } else {
            setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
        setDropChance(EquipmentSlot.MAINHAND, 0.0f);
        rebuildGoals(k);
    }

    private void attr(Holder<Attribute> a, double v) {
        AttributeInstance inst = getAttribute(a);
        if (inst != null) inst.setBaseValue(v);
    }

    @Override
    protected void registerGoals() {
        rebuildGoals(RaiderKind.SCAV);
    }

    private void rebuildGoals(RaiderKind k) {
        this.goalSelector.removeAllGoals(g -> true);
        this.targetSelector.removeAllGoals(g -> true);

        this.goalSelector.addGoal(0, new FloatGoal(this));
        if (k.melee()) {
            this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15, false));
        } else {
            this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0, k.interval, (float) k.range));
        }
        this.goalSelector.addGoal(5, new MoveTowardsRestrictionGoal(this, 0.9));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.7));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 14.0f));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Стрельба: мгновенный выстрел с трассером; шанс попасть зависит от дистанции, стены блокируют. */
    @Override
    public void performRangedAttack(LivingEntity target, float power) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        RaiderKind k = kind();
        Vec3 from = getEyePosition().subtract(0, 0.25, 0);
        Vec3 aim = target.getEyePosition().subtract(0, 0.25, 0);
        double dist = from.distanceTo(aim);

        sl.playSound(null, blockPosition(), SoundEvents.CROSSBOW_SHOOT, SoundSource.HOSTILE, 1.5f, k.soundPitch);
        sl.sendParticles(ParticleTypes.SMOKE, from.x, from.y, from.z, 3, 0.05, 0.05, 0.05, 0.01);

        double chance = Math.max(0.12, Math.min(0.95, k.accuracy * (1.0 - dist / (k.range * 1.6))));
        for (int i = 0; i < k.shots; i++) {
            boolean hit = this.random.nextDouble() < chance;
            Vec3 end = aim;
            if (!hit) {
                end = aim.add((this.random.nextDouble() - 0.5) * 2.4,
                        (this.random.nextDouble() - 0.5) * 1.2,
                        (this.random.nextDouble() - 0.5) * 2.4);
            }
            BlockHitResult br = sl.clip(new ClipContext(from, end, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, this));
            boolean blocked = br.getType() != HitResult.Type.MISS;
            if (blocked) end = br.getLocation();
            tracer(sl, from, end);
            if (hit && !blocked) {
                target.hurt(this.damageSources().mobAttack(this), (float) (k.dmg * StoryManager.dmgMult));
            }
        }
    }

    private static void tracer(ServerLevel sl, Vec3 a, Vec3 b) {
        Vec3 d = b.subtract(a);
        int n = Math.max(1, (int) (d.length() / 1.5));
        for (int i = 1; i <= n; i++) {
            Vec3 p = a.add(d.scale((double) i / n));
            sl.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0.0);
        }
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        if (kind().boss) return;
        if (this.random.nextFloat() < 0.6f) spawnAtLocation(new ItemStack(Items.IRON_NUGGET, 1 + this.random.nextInt(3)));
        if (this.random.nextFloat() < 0.3f) spawnAtLocation(new ItemStack(Items.BREAD, 1 + this.random.nextInt(2)));
        if (this.random.nextFloat() < 0.15f) spawnAtLocation(new ItemStack(LastFrontier.MEDKIT.get()));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Kind", kindId());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Kind")) {
            RaiderKind k = RaiderKind.byId(tag.getString("Kind"));
            this.entityData.set(KIND, k.id);
            if (!this.level().isClientSide()) {
                applyKind(k, false);
            }
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }
}
