package com.lastfrontier;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Хранит прогресс игрока (в persistent data) и двигает сюжет. */
public final class StoryManager {
    static final String KEY = "lastfrontier_story";

    public static CompoundTag data(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(KEY)) {
            root.put(KEY, new CompoundTag());
        }
        return root.getCompound(KEY);
    }

    public static int index(Player p) {
        return data(p).getInt("idx");
    }

    public static Quest current(Player p) {
        int i = index(p);
        return i >= 0 && i < Quests.ALL.size() ? Quests.ALL.get(i) : null;
    }

    public static int progress(Player p) {
        return data(p).getInt("prog");
    }

    public static void setProgress(Player p, int v) {
        data(p).putInt("prog", v);
    }

    public static boolean isStarted(Player p) {
        return data(p).getBoolean("started");
    }

    /** Первый вход в мир: вступление и первый квест. */
    public static void begin(ServerPlayer p) {
        CompoundTag d = data(p);
        if (d.getBoolean("started")) return;
        d.putBoolean("started", true);
        d.putInt("idx", 0);
        p.sendSystemMessage(Component.literal("§6=== ПОСЛЕДНИЙ РУБЕЖ ==="));
        p.sendSystemMessage(Component.literal(
                "§7Мир погиб. Остались лагеря, радио и оружие. Команда §f/lf quest §7покажет текущую цель."));
        run(p, "give @s lastfrontier:survivor_journal 1");
        startQuest(p);
    }

    public static void showQuest(ServerPlayer p) {
        Quest q = current(p);
        if (q == null) {
            p.sendSystemMessage(Component.literal("§6История завершена."));
            return;
        }
        p.sendSystemMessage(Component.literal("§6" + q.chapter()));
        p.sendSystemMessage(Component.literal("§e" + q.title() + " §7(" + (index(p) + 1) + "/" + Quests.ALL.size() + ")"));
        p.sendSystemMessage(Component.literal("§7" + q.description()));
        p.sendSystemMessage(Component.literal("§fПрогресс: " + progress(p) + "/" + q.objective().count()));
    }

    public static void startQuest(ServerPlayer p) {
        Quest q = current(p);
        if (q == null) {
            finish(p);
            return;
        }
        CompoundTag d = data(p);
        d.putInt("prog", 0);
        d.putDouble("sx", p.getX());
        d.putDouble("sz", p.getZ());

        String prevChapter = index(p) > 0 ? Quests.ALL.get(index(p) - 1).chapter() : "";
        if (!q.chapter().equals(prevChapter)) {
            run(p, "title @s subtitle {\"text\":\"" + q.title() + "\"}");
            run(p, "title @s title {\"text\":\"" + q.chapter() + "\"}");
        }
        p.sendSystemMessage(Component.literal("§6[Квест] §e" + q.title()));
        p.sendSystemMessage(Component.literal("§7" + q.description()));
        for (String cmd : q.onStart()) {
            run(p, cmd);
        }
    }

    public static void addProgress(ServerPlayer p, int n) {
        Quest q = current(p);
        if (q == null) return;
        int prog = Math.min(q.objective().count(), progress(p) + n);
        setProgress(p, prog);
        p.displayClientMessage(Component.literal("§e" + q.title() + ": §f" + prog + "/" + q.objective().count()), true);
        if (prog >= q.objective().count()) {
            complete(p);
        }
    }

    public static void complete(ServerPlayer p) {
        Quest q = current(p);
        if (q == null) return;
        p.sendSystemMessage(Component.literal("§a[Квест выполнен] §f" + q.title()));
        if (!q.doneText().isEmpty()) {
            p.sendSystemMessage(Component.literal("§7" + q.doneText()));
        }
        for (String cmd : q.onComplete()) {
            run(p, cmd);
        }
        data(p).putInt("idx", index(p) + 1);
        startQuest(p);
    }

    private static void finish(ServerPlayer p) {
        run(p, "title @s subtitle {\"text\":\"Спасибо за игру\"}");
        run(p, "title @s title {\"text\":\"КОНЕЦ\"}");
        p.sendSystemMessage(Component.literal("§6История завершена. Мир теперь твой."));
    }

    public static void reset(ServerPlayer p) {
        p.getPersistentData().remove(KEY);
    }

    public static void run(ServerPlayer p, String command) {
        MinecraftServer server = p.getServer();
        if (server == null) return;
        try {
            CommandSourceStack src = p.createCommandSourceStack().withPermission(4).withSuppressedOutput();
            server.getCommands().performPrefixedCommand(src, command);
        } catch (Exception e) {
            LastFrontier.LOGGER.warn("Story command failed: {} ({})", command, e.toString());
        }
    }

    private StoryManager() {}
}
