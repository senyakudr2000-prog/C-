package com.lastfrontier.client;

import com.lastfrontier.LastFrontier;
import com.lastfrontier.RaiderEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class RaiderRenderer extends HumanoidMobRenderer<RaiderEntity, HumanoidModel<RaiderEntity>> {

    public RaiderRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public void render(RaiderEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        // стрелки держат оружие перед собой, мутанты идут с пустыми руками
        this.model.rightArmPose = entity.kind().melee()
                ? HumanoidModel.ArmPose.EMPTY
                : HumanoidModel.ArmPose.BOW_AND_ARROW;
        this.model.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(RaiderEntity entity) {
        return ResourceLocation.fromNamespaceAndPath(LastFrontier.MODID,
                "textures/entity/" + entity.kindId() + ".png");
    }
}
