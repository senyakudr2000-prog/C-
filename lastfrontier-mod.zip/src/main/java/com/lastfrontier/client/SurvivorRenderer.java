package com.lastfrontier.client;

import com.lastfrontier.LastFrontier;
import com.lastfrontier.SurvivorEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class SurvivorRenderer extends HumanoidMobRenderer<SurvivorEntity, HumanoidModel<SurvivorEntity>> {

    public SurvivorRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(SurvivorEntity entity) {
        return ResourceLocation.fromNamespaceAndPath(LastFrontier.MODID,
                "textures/entity/" + entity.getSkin() + ".png");
    }
}
