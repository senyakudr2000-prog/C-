package com.lastfrontier;

import com.lastfrontier.Quest.Objective;

import java.util.ArrayList;
import java.util.List;

/**
 * Весь сюжет здесь. Чтобы добавить квест - допиши ещё один new Quest(...) в build().
 * Награды-оружие TaCZ лежат в data/lastfrontier/function/reward/*.mcfunction
 * (их можно править без перекомпиляции кода, но jar пересобирать всё равно надо).
 */
public final class Quests {
    // ВАЖНО: OFFSETS должен быть объявлен раньше ALL (порядок статической инициализации)
    private static final int[][] OFFSETS = {
            {6, 0}, {-6, 0}, {0, 6}, {0, -6}, {5, 5}, {-5, -5}, {5, -5}, {-5, 5}
    };

    public static final List<Quest> ALL = build();

    private static final String CH0 = "Пролог: Пепел и дым";
    private static final String CH1 = "Глава 1: Голос в эфире";
    private static final String CH2 = "Глава 2: Предатель";
    private static final String CH3 = "Глава 3: Рассвет";

    private static List<Quest> build() {
        List<Quest> l = new ArrayList<>();

        // ---------- ПРОЛОГ ----------
        l.add(new Quest("q01", CH0, "Первый контакт",
                "Ты очнулся среди руин. У костра сидит человек - поговори с ним.",
                Objective.talk("old_sam", List.of(
                        "Живой? Редкость. Меня зовут Сэм. Я здесь дольше, чем помню.",
                        "Мир сгорел двадцать лет назад. Остались лагеря, радио и твари в темноте.",
                        "Нам нужен металл, чтобы укрепить ворота. Принеси восемь железных слитков.")),
                List.of(ensureNpc("old_sam")),
                List.of(give("minecraft:bread", 8)),
                "Сэм протянул тебе паёк."));

        l.add(new Quest("q02", CH0, "Металлолом",
                "Добудь 8 железных слитков для ворот лагеря.",
                Objective.collect("minecraft:iron_ingot", 8),
                List.of(),
                List.of(give("minecraft:cooked_beef", 16), xp(100)),
                "Сэм: «Хватит на ворота. Но на закате придут мутанты. Будь готов.»"));

        l.add(new Quest("q03", CH0, "Ночная зачистка",
                "К лагерю идут мутанты. Убей 6 светящихся тварей.",
                Objective.killTag("lf_mutant", 6),
                wave("minecraft:zombie", "lf_mutant", "Мутант", 6),
                List.of("function lastfrontier:reward/gun_pistol",
                        "function lastfrontier:reward/ammo_pistol",
                        give("minecraft:leather_chestplate", 1), xp(150)),
                "Сэм вручил тебе оружие из старого тайника. Береги патроны."));

        // ---------- ГЛАВА 1 ----------
        l.add(new Quest("q04", CH1, "Нина на связи",
                "В лагере появилась радистка. Она поймала странный сигнал.",
                Objective.talk("radio_nina", List.of(
                        "Тише... слышишь? Это не шум. Это позывной.",
                        "Сигнал идёт с северной вышки, километрах в трёхстах отсюда.",
                        "Там может быть уцелевший город. Пройди триста блоков от лагеря и найди вышку.")),
                List.of(ensureNpc("radio_nina")),
                List.of(give("minecraft:compass", 1)),
                "Нина отметила направление на твоём компасе... если бы компасы здесь работали."));

        l.add(new Quest("q05", CH1, "Дорога к вышке",
                "Отойди на 300 блоков от места, где получил задание.",
                Objective.travel(300),
                List.of(),
                List.of(give("minecraft:golden_apple", 2), xp(200)),
                "Впереди виднеется мачта. Передатчик разбит - нужны детали."));

        l.add(new Quest("q06", CH1, "Детали передатчика",
                "Собери 12 красной пыли для ремонта передатчика.",
                Objective.collect("minecraft:redstone", 12),
                List.of(),
                List.of(xp(150), give("minecraft:arrow", 32)),
                "Передатчик ожил. В эфире - чужой голос. И за тобой идут."));

        l.add(new Quest("q07", CH1, "Засада мародёров",
                "Мародёры услышали сигнал. Убей 6 нападающих.",
                Objective.killTag("lf_raider", 6),
                wave("minecraft:pillager", "lf_raider", "Мародёр", 6),
                List.of("function lastfrontier:reward/gun_rifle",
                        "function lastfrontier:reward/ammo_rifle", xp(250)),
                "У мародёров нашлась хорошая винтовка. Теперь у тебя есть чем отвечать."));

        // ---------- ГЛАВА 2 ----------
        l.add(new Quest("q08", CH2, "Капитан Вэнс",
                "К вышке прибыл отряд. Их капитан хочет с тобой поговорить.",
                Objective.talk("captain_vance", List.of(
                        "Хороший выстрел, парень. Я капитан Вэнс, отряд «Рассвет».",
                        "Мародёров ведёт Главарь. Он держит бункер на севере и глушит эфир.",
                        "Если мы хотим связаться с другими городами - бункер надо брать. Идёшь со мной?")),
                List.of(ensureNpc("captain_vance")),
                List.of(give("minecraft:shield", 1)),
                "Вэнс отдал тебе трофейный щит."));

        l.add(new Quest("q09", CH2, "Марш на север",
                "Пройди 500 блоков в сторону бункера.",
                Objective.travel(500),
                List.of(),
                List.of(give("minecraft:golden_carrot", 16), xp(300)),
                "Бункер на горизонте. Ворота охраняют люди Главаря."));

        l.add(new Quest("q10", CH2, "Главарь мародёров",
                "Убей Главаря. Его стража не в счёт, но лучше расправиться и с ней.",
                Objective.killTag("lf_boss_warlord", 1),
                concat(wave("minecraft:pillager", "lf_guard", "Страж бункера", 3),
                        List.of(boss("minecraft:vindicator", "lf_boss_warlord", "Главарь мародёров", 120))),
                List.of("function lastfrontier:reward/gun_shotgun",
                        "function lastfrontier:reward/ammo_shotgun", xp(500)),
                "Главарь пал. Эфир чист - но в нём прозвучал новый голос."));

        // ---------- ГЛАВА 3 ----------
        l.add(new Quest("q11", CH3, "Энергоячейки",
                "Собери 16 золотых слитков для антенны дальнего действия.",
                Objective.collect("minecraft:gold_ingot", 16),
                List.of(),
                List.of(give("minecraft:cooked_porkchop", 16), xp(300)),
                "Антенна собрана. Нина ждёт у передатчика."));

        l.add(new Quest("q12", CH3, "Последний сеанс связи",
                "Поговори с Ниной у передатчика.",
                Objective.talk("radio_nina", List.of(
                        "Получилось! Я слышу города. Живые, настоящие!",
                        "Но кто-то глушит нас снова. Тёмный Генерал - он командовал мародёрами.",
                        "Он идёт сюда. Закрепись и встреть его. Это последний бой.")),
                List.of(ensureNpc("radio_nina")),
                List.of(give("minecraft:golden_apple", 4)),
                "Нина включила сигнал. Времени мало."));

        l.add(new Quest("q13", CH3, "Тёмный Генерал",
                "Победи Тёмного Генерала. Его мутанты не в счёт.",
                Objective.killTag("lf_boss_general", 1),
                concat(wave("minecraft:zombie", "lf_mutant2", "Мутант-гвардеец", 6),
                        List.of(boss("minecraft:wither_skeleton", "lf_boss_general", "Тёмный Генерал", 300))),
                List.of("function lastfrontier:reward/ammo_pack", xp(1000)),
                "Генерал повержен. Эфир наполнился голосами."));

        l.add(new Quest("q14", CH3, "Эпилог",
                "Вернись к Сэму.",
                Objective.talk("old_sam", List.of(
                        "Я слышу радио... Люди зовут друг друга.",
                        "Мир не сгорел до конца, а ты помог ему проснуться.",
                        "Спасибо тебе, выживший.")),
                List.of(ensureNpc("old_sam")),
                List.of(give("minecraft:diamond", 5), xp(500)),
                ""));

        return List.copyOf(l);
    }

    // ---------- помощники для команд ----------

    private static String give(String item, int n) {
        return "give @s " + item + " " + n;
    }

    private static String xp(int n) {
        return "xp add @s " + n + " points";
    }

    public static String npcSummon(String id) {
        String name = Npcs.NAMES.get(id);
        return "summon lastfrontier:survivor ^ ^ ^4 {Skin:\"" + id + "\",NoAI:1b,Invulnerable:1b,PersistenceRequired:1b,Silent:1b,"
                + "CustomNameVisible:1b,CustomName:'{\"text\":\"" + name + "\"}',"
                + "Tags:[\"" + Npcs.TAG_PREFIX + id + "\"]}";
    }

    private static String ensureNpc(String id) {
        return "execute unless entity @e[tag=" + Npcs.TAG_PREFIX + id + ",distance=..300] run " + npcSummon(id);
    }

    private static List<String> wave(String type, String tag, String name, int n) {
        List<String> cmds = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int[] o = OFFSETS[i % OFFSETS.length];
            cmds.add("summon " + type + " ~" + o[0] + " ~1 ~" + o[1]
                    + " {Glowing:1b,PersistenceRequired:1b,CustomName:'{\"text\":\"" + name + "\"}',"
                    + "Tags:[\"" + tag + "\"]}");
        }
        return cmds;
    }

    private static String boss(String type, String tag, String name, int hp) {
        return "summon " + type + " ~8 ~1 ~ {Glowing:1b,PersistenceRequired:1b,CustomNameVisible:1b,"
                + "CustomName:'{\"text\":\"" + name + "\"}',Tags:[\"" + tag + "\"],"
                + "attributes:[{id:\"minecraft:generic.max_health\",base:" + hp + "d}],Health:" + hp + "f}";
    }

    @SafeVarargs
    private static List<String> concat(List<String>... lists) {
        List<String> out = new ArrayList<>();
        for (List<String> x : lists) out.addAll(x);
        return out;
    }

    private Quests() {}
}
