package com.lastfrontier;

import com.lastfrontier.Quest.Objective;
import com.lastfrontier.Quest.Spawn;

import java.util.ArrayList;
import java.util.List;

/**
 * Весь сюжет здесь. Чтобы добавить квест, допиши ещё один new Quest(...) в build().
 * Оружие и патроны TaCZ выдаются функциями data/lastfrontier/function/reward/*.mcfunction
 */
public final class Quests {
    private static final String CH0 = "Пролог: Южный пост";
    private static final String CH1 = "Глава 1: Мёртвый город";
    private static final String CH2 = "Глава 2: Закон улиц";
    private static final String CH3 = "Глава 3: Голос Приюта";

    public static final List<Quest> ALL = build();

    private static List<Quest> build() {
        List<Quest> l = new ArrayList<>();

        // ---------- ПРОЛОГ ----------
        l.add(new Quest("q01", CH0, "Южный пост",
                "Поговори со Сэмом у костра в лагере.",
                Objective.talk("old_sam", List.of(
                        "Очнулся? Хорошо. Ты три дня пролежал без сознания, мы нашли тебя у дороги.",
                        "Это «Новый Приют». Двадцать лет назад здесь жили сто тысяч человек. Теперь остались мы и Шакалы.",
                        "Шакалы - банда мародёров. Они держат центр города и жгут сигнальные костры.",
                        "Берёшь этот пистолет. Они уже идут к воротам, держись за баррикадой!")),
                "camp", List.of(), List.of(),
                List.of("function lastfrontier:reward/gun_pistol",
                        "function lastfrontier:reward/ammo_pistol",
                        give("minecraft:cooked_beef", 6)),
                "Сэм вручил тебе оружие: «Не трать патроны зря.»"));

        l.add(new Quest("q02", CH0, "Шакалы у ворот",
                "Отбей атаку: 4 Шакала идут по Южной улице. Стреляют они метко, не стой на открытом месте.",
                Objective.killTag("lf_q2", 4),
                "gate",
                List.of(sp("scav", "gate", 4, "lf_q2")),
                List.of(),
                List.of(give("minecraft:bread", 8), xp(120)),
                "Сэм: «Неплохо. Но это были мелкие сошки. Лагерю нужны аптечки, а они в магазине.»"));

        // ---------- ГЛАВА 1 ----------
        l.add(new Quest("q03", CH1, "Аптечки из магазина",
                "Найди 2 аптечки. Они лежат в сундуке в магазине (северо-восток). Внутри засели Шакалы и мутанты.",
                Objective.collect("lastfrontier:medkit", 2),
                "shop",
                List.of(sp("scav", "shop", 2, "lf_guard"), sp("mutant", "shop", 2, "lf_guard")),
                List.of(),
                List.of(give("minecraft:cooked_beef", 8), xp(200)),
                "Сэм: «Теперь есть чем лечиться. Но генератор встал, а без света нам не выжить.»"));

        l.add(new Quest("q03b", CH1, "Топливо для генератора",
                "Найди 2 канистры с топливом на АЗС (юго-запад). Сэм: «Генератор лагеря встал. Без света нас перережут ночью.» На АЗС засели Шакалы и бегуны.",
                Objective.collect("lastfrontier:fuel_canister", 2),
                "gas",
                List.of(sp("scav", "gas", 2, "lf_guard"), sp("runner", "gas", 3, "lf_guard")),
                List.of(),
                List.of(give("minecraft:iron_chestplate", 1), give("minecraft:cooked_beef", 8), xp(250)),
                "Генератор заработал, в лагере зажёгся свет. Сэм: «Теперь иди к Нине на север, на радиовышку.»"));

        l.add(new Quest("q04", CH1, "Голос в эфире",
                "Дойди до радиовышки на севере и поговори с Ниной.",
                Objective.talk("radio_nina", List.of(
                        "Ты от Сэма? Слушай внимательно. Я ловлю сигнал из «Ковчега» - убежища за горами.",
                        "Мой передатчик сломан. Нужны три вещи: предохранитель со склада, аккумулятор из больницы и кристалл антенны.",
                        "Кристалл у главаря Шакалов. Он держит его в бункере на севере. Но сначала - осторожно, они уже заметили вышку!")),
                "tower", List.of(), List.of(),
                List.of(xp(150)),
                "Нина: «Держись у входа. Они идут.»"));

        l.add(new Quest("q05", CH1, "Оборона вышки",
                "Шакалы напали на вышку! Убей 5 нападающих, среди них есть снайпер.",
                Objective.killTag("lf_q5", 5),
                "nplaza",
                List.of(sp("raider", "nplaza", 4, "lf_q5"), sp("sniper", "nplaza", 1, "lf_q5")),
                List.of(),
                List.of("function lastfrontier:reward/gun_rifle",
                        "function lastfrontier:reward/ammo_rifle", xp(300)),
                "Нина достала из ящика винтовку: «Это от моего отца. Теперь твоё.»"));

        l.add(new Quest("q06", CH1, "Предохранитель",
                "Найди предохранитель на складе (юго-запад). Склад кишит мутантами и охраной.",
                Objective.collect("lastfrontier:fuse", 1),
                "warehouse",
                List.of(sp("mutant", "warehouse", 3, "lf_guard"), sp("scav", "warehouse", 1, "lf_guard"),
                        sp("heavy", "warehouse", 1, "lf_guard")),
                List.of(),
                List.of(give("minecraft:golden_apple", 1), xp(250)),
                "Предохранитель у тебя. Осталось найти аккумулятор в больнице."));

        l.add(new Quest("q07", CH1, "Аккумулятор",
                "Найди аккумулятор в больнице (северо-запад). Он лежит в сундуке на втором этаже. На крыше сидит снайпер.",
                Objective.collect("lastfrontier:battery", 1),
                "hospital",
                List.of(sp("raider", "hospital", 2, "lf_guard"), sp("sniper", "hospital", 1, "lf_guard"),
                        sp("mutant", "hospital", 2, "lf_guard")),
                List.of(),
                List.of(give("minecraft:golden_apple", 1), xp(300)),
                "Аккумулятор найден. Остались схема и образец: Нина просила и их."));

        l.add(new Quest("q07b", CH1, "Схема передатчика",
                "Найди схему передатчика в школе (юго-восток) в сундуке на втором этаже. По коридорам рыщут Шакалы и бегуны.",
                Objective.collect("lastfrontier:schematic", 1),
                "school",
                List.of(sp("raider", "school", 3, "lf_guard"), sp("heavy", "school", 1, "lf_guard"),
                        sp("runner", "school", 2, "lf_guard")),
                List.of(),
                List.of(give("minecraft:golden_apple", 1), "function lastfrontier:reward/ammo_rifle", xp(350)),
                "Схема найдена. Нина сможет собрать по ней передатчик."));

        l.add(new Quest("q07c", CH1, "Образец из лаборатории",
                "Найди образец мутанта в лаборатории (северо-запад), в сундуке на втором этаже. Там ходит Громила, он бьёт больно. Держи дистанцию!",
                Objective.collect("lastfrontier:mutant_sample", 1),
                "lab",
                List.of(sp("brute", "lab", 1, "lf_guard"), sp("mutant", "lab", 2, "lf_guard"),
                        sp("runner", "lab", 2, "lf_guard")),
                List.of(),
                List.of(give("minecraft:golden_apple", 2), "function lastfrontier:reward/ammo_pack", xp(500)),
                "Образец у тебя. По рации выходит капитан Вэнс: ему нужна помощь в полицейском участке."));

        // ---------- ГЛАВА 2 ----------
        l.add(new Quest("q08", CH2, "Капитан Вэнс",
                "В полицейском участке (северо-восток) держится капитан Вэнс. Поговори с ним.",
                Objective.talk("captain_vance", List.of(
                        "Капитан Вэнс, бывший начальник участка. Держусь здесь с горсткой людей, Шакалы нас осадили.",
                        "Помоги отбиться. А за помощь отдам ключ-карту от бункера: там главарь прячет кристалл антенны.",
                        "Они идут с площади. Огневых точек у них хватает, так что используй укрытия.")),
                "police", List.of(), List.of(),
                List.of(xp(150)),
                "Вэнс кивнул: «Вот и посмотрим, чего ты стоишь.»"));

        l.add(new Quest("q09", CH2, "Осада участка",
                "Отбей атаку Шакалов: 6 бойцов, среди них тяжёлый с дробовиком.",
                Objective.killTag("lf_q9", 6),
                "plaza",
                List.of(sp("raider", "plaza", 3, "lf_q9"), sp("heavy", "plaza", 1, "lf_q9"),
                        sp("scav", "plaza", 2, "lf_q9")),
                List.of(),
                List.of(give("minecraft:cooked_beef", 8), xp(400)),
                "Вэнс: «Ключ-карта в сейфе на втором этаже. Забирай.»"));

        l.add(new Quest("q10", CH2, "Ключ-карта",
                "Найди ключ-карту в сундуке на втором этаже участка.",
                Objective.collect("lastfrontier:keycard", 1),
                "police",
                List.of(), List.of(),
                List.of(xp(200)),
                "Ключ-карта у тебя. Бункер на северо-востоке, на краю города."));

        l.add(new Quest("q11", CH2, "Главарь Шакалов",
                "Штурмуй бункер и убей Главаря. Его охрана в бою не прощает ошибок.",
                Objective.killTag("lf_boss_warlord", 1),
                "bunker",
                List.of(sp("warlord", "bunker", 1, "lf_boss_warlord"),
                        sp("raider", "bunker", 2, "lf_guard"),
                        sp("heavy", "bunker", 1, "lf_guard"),
                        sp("sniper", "bunker", 1, "lf_guard")),
                List.of(),
                List.of("function lastfrontier:reward/gun_shotgun",
                        "function lastfrontier:reward/ammo_shotgun",
                        "give @s lastfrontier:antenna_crystal 1", xp(800)),
                "Главарь пал. Из его вещей выпал кристалл антенны."));

        // ---------- ГЛАВА 3 ----------
        l.add(new Quest("q12", CH3, "Передатчик",
                "Вернись на радиовышку к Нине: у тебя есть всё, чтобы запустить передатчик.",
                Objective.talk("radio_nina", List.of(
                        "Предохранитель, аккумулятор, схема, кристалл... Включаю! Образец мутанта я тоже проверила.",
                        "Мутанты - это бывшие жители. Вирус вышел из лаборатории в Тихий день, а Вэнс скрыл правду.",
                        "Есть сигнал! «Ковчег» отвечает! Но слушай, в архиве эфира я нашла запись...",
                        "Голос на ней - Вэнс. Он продал Приют Шакалам, а главаря использовал как пешку. Бункер ему нужен был для себя.",
                        "Он знает, что ты идёшь. Готовься, он будет здесь с людьми.")),
                "tower", List.of(), List.of(),
                List.of("kill @e[tag=lf_npc_captain_vance]", xp(300)),
                "Нина: «Вэнс уже на подходе. Держись у вышки!»"));

        l.add(new Quest("q13", CH3, "Последняя оборона",
                "Отбей штурм вышки: 12 бойцов Вэнса с площади и проспекта, среди них бегуны и снайпер.",
                Objective.killTag("lf_q13", 12),
                "nplaza",
                List.of(sp("raider", "nplaza", 3, "lf_q13"), sp("scav", "nplaza", 2, "lf_q13"),
                        sp("sniper", "nplaza", 1, "lf_q13"),
                        sp("heavy", "plaza", 2, "lf_q13"), sp("raider", "plaza", 2, "lf_q13"),
                        sp("runner", "plaza", 2, "lf_q13")),
                List.of(),
                List.of("function lastfrontier:reward/ammo_pack", xp(600)),
                "Остался только он, Вэнс."));

        l.add(new Quest("q14", CH3, "Капитан Вэнс",
                "Убей предателя. Он стреляет точно и держит дистанцию.",
                Objective.killTag("lf_boss_general", 1),
                "nplaza",
                List.of(sp("general", "nplaza", 1, "lf_boss_general"),
                        sp("raider", "nplaza", 2, "lf_guard"),
                        sp("heavy", "nplaza", 1, "lf_guard")),
                List.of(),
                List.of(xp(1000), give("minecraft:diamond", 3)),
                "Вэнс мёртв. Приют больше никому не продадут."));

        l.add(new Quest("q15", CH3, "Ковчег отвечает",
                "Вернись к Нине и выслушай ответ «Ковчега».",
                Objective.talk("radio_nina", List.of(
                        "«Новый Приют, вас слышим. Высылаем колонну. Держитесь».",
                        "Ты слышишь? Они идут за нами! Двадцать лет тишины - и вот.",
                        "Спасибо тебе, выживший. Город теперь твой.")),
                "tower", List.of(), List.of(),
                List.of(give("minecraft:diamond", 5), give("minecraft:golden_apple", 4), xp(1500)),
                ""));

        return List.copyOf(l);
    }

    private static Spawn sp(String kind, String zone, int count, String tag) {
        return new Spawn(kind, zone, count, tag);
    }

    private static String give(String item, int n) {
        return "give @s " + item + " " + n;
    }

    private static String xp(int n) {
        return "xp add @s " + n + " points";
    }

    private Quests() {}
}
