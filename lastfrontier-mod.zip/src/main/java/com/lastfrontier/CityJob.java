package com.lastfrontier;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.function.Consumer;

/** Строит город частями, по несколько сотен блоков за тик, чтобы не вешать игру. */
@EventBusSubscriber(modid = LastFrontier.MODID)
public final class CityJob {
    private static final List<CityJob> JOBS = new ArrayList<>();

    private final UUID playerId;
    private final ServerLevel level;
    private final City city;
    private final Random rng;
    private final List<City.Put> puts = new ArrayList<>();
    private final List<Consumer<ServerLevel>> post = new ArrayList<>();
    private final int columns = City.SIZE * City.SIZE;
    private int col = 0;
    private int idx = 0;
    private int postIdx = 0;
    private int lastPct = -1;

    private CityJob(ServerPlayer p, City city) {
        this.playerId = p.getUUID();
        this.level = p.serverLevel();
        this.city = city;
        this.rng = new Random(city.ox * 341873128712L + city.oz * 132897987541L);
        city.plan(rng, puts, post);
    }

    public static boolean running(UUID id) {
        for (CityJob j : JOBS) {
            if (j.playerId.equals(id)) return true;
        }
        return false;
    }

    public static void start(ServerPlayer p, City city) {
        JOBS.add(new CityJob(p, city));
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post e) {
        if (JOBS.isEmpty()) return;
        Iterator<CityJob> it = JOBS.iterator();
        while (it.hasNext()) {
            CityJob j = it.next();
            boolean done;
            try {
                done = j.step();
            } catch (Exception ex) {
                LastFrontier.LOGGER.error("City generation failed", ex);
                done = true;
            }
            if (done) it.remove();
        }
    }

    private boolean step() {
        ServerPlayer p = level.getServer().getPlayerList().getPlayer(playerId);
        if (p == null) return true; // игрок вышел: при следующем входе стройка начнётся заново

        if (col < columns) {
            for (int k = 0; k < 80 && col < columns; k++) {
                city.column(level, col++, rng);
            }
            progress(p);
            return false;
        }
        if (idx < puts.size()) {
            for (int k = 0; k < 1200 && idx < puts.size(); k++) {
                City.Put put = puts.get(idx++);
                level.setBlock(put.pos(), put.state(), 2);
            }
            progress(p);
            return false;
        }
        if (postIdx < post.size()) {
            for (int k = 0; k < 100 && postIdx < post.size(); k++) {
                post.get(postIdx++).accept(level);
            }
            return false;
        }
        finish(p);
        return true;
    }

    private void progress(ServerPlayer p) {
        int total = columns + puts.size();
        int pct = (int) ((long) (col + idx) * 100 / Math.max(1, total));
        if (pct / 10 != lastPct / 10) {
            lastPct = pct;
            p.displayClientMessage(Component.literal("§eГород строится: " + pct + "%"), true);
        }
    }

    private void finish(ServerPlayer p) {
        CompoundTag d = StoryManager.data(p);
        d.putBoolean("ready", true);
        if (!d.getBoolean("npcs")) {
            d.putBoolean("npcs", true);
            city.spawnNpcs(level);
            city.spawnAmbient(level, rng);
        }
        BlockPos s = city.playerSpawn();
        p.teleportTo(s.getX() + 0.5, s.getY(), s.getZ() + 0.5);
        p.setRespawnPosition(level.dimension(), s, 0f, true, false);
        StoryManager.run(p, "give @s lastfrontier:survivor_journal 1");
        p.sendSystemMessage(Component.literal("§6Город «Новый Приют» готов. Ты в лагере у Южного поста."));
        StoryManager.startQuest(p);
    }
}
